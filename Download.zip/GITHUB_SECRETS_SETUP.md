# CAEMS – GitHub Actions: Secrets & Konfiguration

## Benötigte GitHub Secrets

Unter: **Repository → Settings → Secrets and variables → Actions**

### Allgemein (alle Umgebungen)
| Secret | Beschreibung | Beispiel |
|--------|-------------|---------|
| `CODECOV_TOKEN` | Codecov.io Token für Coverage-Reports | `abc123...` |
| `VITE_API_BASE_URL` | API-URL für Frontend-Build | `https://api.caems.example.com/api/v1` |
| `SLACK_WEBHOOK_URL` | Slack Incoming Webhook für Notifications | `https://hooks.slack.com/...` |

### Staging (Environment: `staging`)
| Secret | Beschreibung |
|--------|-------------|
| `STAGING_HOST` | IP oder Hostname des Staging-Servers |
| `STAGING_USER` | SSH-Benutzer (z.B. `deploy`) |
| `STAGING_SSH_KEY` | Privater SSH-Schlüssel (PEM-Format) |

### Produktion (Environment: `production`)
| Secret | Beschreibung |
|--------|-------------|
| `PROD_HOST` | IP oder Hostname des Produktions-Servers |
| `PROD_USER` | SSH-Benutzer |
| `PROD_SSH_KEY` | Privater SSH-Schlüssel |

---

## Environments einrichten

Unter **Repository → Settings → Environments**:

### `staging`
- ✅ Keine Approval erforderlich
- Deployment-Branch: `develop`

### `production`
- ✅ **Required reviewers**: min. 1 Person
- ✅ Wait timer: 5 Minuten (optional)
- Deployment-Branch: `main`

---

## SSH-Key für Deploy-Server einrichten

```bash
# Schlüsselpaar generieren (auf lokalem Rechner)
ssh-keygen -t ed25519 -C "github-actions-deploy" -f ~/.ssh/caems_deploy

# Public Key auf den Server kopieren
ssh-copy-id -i ~/.ssh/caems_deploy.pub deploy@DEIN-SERVER

# Privaten Key als GitHub Secret hinterlegen
cat ~/.ssh/caems_deploy  # → Inhalt in PROD_SSH_KEY / STAGING_SSH_KEY einfügen
```

---

## Server-Vorbereitung (einmalig)

```bash
# Auf dem Produktions-/Staging-Server ausführen:

# Docker installieren
curl -fsSL https://get.docker.com | sh
usermod -aG docker deploy

# Verzeichnis anlegen
mkdir -p /opt/caems /opt/backups
cd /opt/caems

# docker-compose.yml und .env hochladen
# (z.B. via scp oder git clone)

# .env befüllen
cp .env.example .env
nano .env

# Ersten Start durchführen
docker compose up -d
```

---

## Pipeline-Übersicht

```
Push to develop / main
        │
        ├─► 🧪 backend-test     (JUnit + Integrationstests + Coverage)
        ├─► 🎨 frontend-test    (Vitest + ESLint + Build-Check)
        │
        └─► 🔐 security-scan   (OWASP + Trivy FS-Scan)
                │
                └─► 🐳 docker-build  (Multi-Arch Build + Push zu GHCR)
                            │
                   develop ─┴─► 🚀 deploy-staging   + Smoke-Test
                   main    ────► 🏁 deploy-production + DB-Backup + Smoke-Test + Slack
```

---

## Branch-Strategie

| Branch | Pipeline | Deploy |
|--------|---------|--------|
| `feature/*` | Tests + Lint | – |
| `develop` | Tests + Build + Push | → Staging |
| `main` | Tests + Build + Push | → Produktion |
| Pull Request | Tests + Security | – |
