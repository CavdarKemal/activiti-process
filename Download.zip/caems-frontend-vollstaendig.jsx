import { useState, useEffect, createContext, useContext, useCallback } from "react";

// ═══════════════════════════════════════════════════════════
// API LAYER  (axios-like fetch wrapper)
// ═══════════════════════════════════════════════════════════
const BASE = "http://localhost:8080/api/v1";

const api = {
  async request(method, path, body) {
    const token = localStorage.getItem("jwt");
    const res = await fetch(`${BASE}${path}`, {
      method,
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
    if (res.status === 401) { AuthCtx.logout?.(); return; }
    if (!res.ok) { const err = await res.json().catch(() => ({})); throw err; }
    if (res.status === 204) return null;
    return res.json();
  },
  get:    (path)       => api.request("GET",    path),
  post:   (path, body) => api.request("POST",   path, body),
  put:    (path, body) => api.request("PUT",    path, body),
  delete: (path)       => api.request("DELETE", path),
};

// ═══════════════════════════════════════════════════════════
// AUTH CONTEXT
// ═══════════════════════════════════════════════════════════
const AuthContext = createContext(null);
let AuthCtx = {};

function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const token = localStorage.getItem("jwt");
    const email = localStorage.getItem("userEmail");
    return token ? { email, token } : null;
  });

  const login = async (email, password) => {
    const data = await api.post("/auth/login", { email, password });
    localStorage.setItem("jwt", data.token);
    localStorage.setItem("userEmail", email);
    setUser({ email, token: data.token });
  };

  const logout = () => {
    localStorage.removeItem("jwt");
    localStorage.removeItem("userEmail");
    setUser(null);
  };

  AuthCtx = { login, logout };
  return <AuthContext.Provider value={{ user, login, logout }}>{children}</AuthContext.Provider>;
}
const useAuth = () => useContext(AuthContext);

// ═══════════════════════════════════════════════════════════
// MOCK DATA (falls Backend offline)
// ═══════════════════════════════════════════════════════════
const EMPLOYEES = [
  { id:1, employeeNumber:"EMP-001", firstName:"Maximilian", lastName:"Bauer", email:"m.bauer@firma.de", phone:"+49 30 1234567", position:"Senior Developer", department:"Engineering", hireDate:"2021-03-15", salary:85000, active:true },
  { id:2, employeeNumber:"EMP-002", firstName:"Sophie", lastName:"Müller", email:"s.mueller@firma.de", phone:"+49 89 9876543", position:"Product Manager", department:"Product", hireDate:"2020-07-01", salary:90000, active:true },
  { id:3, employeeNumber:"EMP-003", firstName:"Jonas", lastName:"Weber", email:"j.weber@firma.de", phone:"+49 40 5555888", position:"UX Designer", department:"Design", hireDate:"2022-01-10", salary:72000, active:true },
];
const HARDWARE = [
  { id:1, assetTag:"HW-0001", name:'MacBook Pro 16"', category:"LAPTOP", manufacturer:"Apple", model:"MK183D/A", serialNumber:"C02XY12345", status:"AVAILABLE", purchasePrice:2899, warrantyUntil:"2025-06-01" },
  { id:2, assetTag:"HW-0002", name:"Dell UltraSharp 27\"", category:"MONITOR", manufacturer:"Dell", model:"U2722D", serialNumber:"D3L7890", status:"LOANED", purchasePrice:549, warrantyUntil:"2025-06-15", loanedTo:1 },
  { id:3, assetTag:"HW-0003", name:"ThinkPad X1 Carbon", category:"LAPTOP", manufacturer:"Lenovo", model:"Gen 10", serialNumber:"LNV4567", status:"AVAILABLE", purchasePrice:1899, warrantyUntil:"2024-11-10" },
  { id:4, assetTag:"HW-0004", name:"iPad Pro 12.9\"", category:"TABLET", manufacturer:"Apple", model:"MNXR3FD/A", serialNumber:"DMPH1234", status:"AVAILABLE", purchasePrice:1299, warrantyUntil:"2026-02-20" },
];
const SOFTWARE = [
  { id:1, name:"Microsoft 365", vendor:"Microsoft", version:"2024", category:"PRODUCTIVITY", licenseType:"SUBSCRIPTION", totalLicenses:50, usedLicenses:32, costPerLicense:12.50, renewalDate:"2025-01-01" },
  { id:2, name:"JetBrains IntelliJ IDEA", vendor:"JetBrains", version:"2024.1", category:"DEV_TOOLS", licenseType:"SUBSCRIPTION", totalLicenses:15, usedLicenses:8, costPerLicense:24.90, renewalDate:"2025-06-30" },
  { id:3, name:"Figma Business", vendor:"Figma", version:"Web", category:"DESIGN", licenseType:"SUBSCRIPTION", totalLicenses:10, usedLicenses:7, costPerLicense:45.00, renewalDate:"2025-09-01" },
];

// ═══════════════════════════════════════════════════════════
// DESIGN TOKENS
// ═══════════════════════════════════════════════════════════
const T = {
  primary: "#3d52a0", primaryLight: "#7091e6", primaryDark: "#1e2a5e",
  accent: "#8697c4", bg: "#f0f4ff", surface: "#ffffff",
  border: "#dde3f0", text: "#1a1f36", textMuted: "#6b7280",
  success: "#059669", warning: "#d97706", danger: "#dc2626",
  shadow: "0 2px 8px rgba(61,82,160,.12)",
  radius: 12,
};

const DEPT = { Engineering:"#3b82f6", Product:"#8b5cf6", Design:"#ec4899", "Human Resources":"#f59e0b", Marketing:"#10b981" };
const HW_EMOJI = { LAPTOP:"💻", MONITOR:"🖥️", TABLET:"📱", PERIPHERAL:"⌨️", PRINTER:"🖨️", PHONE:"📞" };
const STATUS = {
  AVAILABLE: { color:"#059669", bg:"#d1fae5", label:"Verfügbar" },
  LOANED:    { color:"#d97706", bg:"#fef3c7", label:"Ausgeliehen" },
  MAINTENANCE:{ color:"#7c3aed", bg:"#ede9fe", label:"Wartung" },
  RETIRED:   { color:"#6b7280", bg:"#f3f4f6", label:"Ausgemustert" },
};

// ═══════════════════════════════════════════════════════════
// TINY COMPONENTS
// ═══════════════════════════════════════════════════════════
const Avatar = ({ name, size=40 }) => {
  const initials = name?.split(" ").map(w=>w[0]).join("").slice(0,2) || "?";
  return (
    <div style={{ width:size, height:size, borderRadius:size/2, background:T.primaryLight+"33",
      display:"flex", alignItems:"center", justifyContent:"center",
      fontSize:size*0.35, fontWeight:700, color:T.primary, flexShrink:0,
      border:`2px solid ${T.primaryLight}55` }}>
      {initials}
    </div>
  );
};

const Badge = ({ label, color="#374151", bg="#f3f4f6", sm }) => (
  <span style={{ background:bg, color, borderRadius:20, padding:sm?"2px 8px":"3px 10px",
    fontSize:sm?10:11, fontWeight:600, whiteSpace:"nowrap", letterSpacing:"0.2px" }}>
    {label}
  </span>
);

const Btn = ({ children, onClick, variant="primary", sm, disabled, type="button" }) => {
  const styles = {
    primary: { background:T.primary, color:"#fff", border:"none" },
    secondary: { background:"transparent", color:T.primary, border:`1.5px solid ${T.primary}` },
    danger: { background:T.danger, color:"#fff", border:"none" },
    ghost: { background:"transparent", color:T.textMuted, border:`1px solid ${T.border}` },
  };
  return (
    <button type={type} onClick={onClick} disabled={disabled} style={{
      ...styles[variant], padding:sm?"6px 12px":"9px 18px",
      borderRadius:8, fontSize:sm?12:13, fontWeight:600, cursor:disabled?"not-allowed":"pointer",
      display:"flex", alignItems:"center", gap:6, opacity:disabled?.6:1,
      transition:"all .15s", whiteSpace:"nowrap",
    }}>{children}</button>
  );
};

const Input = ({ label, value, onChange, type="text", placeholder, required, error, hint }) => (
  <div style={{ display:"flex", flexDirection:"column", gap:5 }}>
    {label && <label style={{ fontSize:12, fontWeight:600, color:T.text }}>{label}{required&&" *"}</label>}
    <input type={type} value={value} onChange={onChange} placeholder={placeholder} required={required}
      style={{ padding:"9px 12px", borderRadius:8, border:`1.5px solid ${error?T.danger:T.border}`,
        fontSize:13, color:T.text, outline:"none", background:T.surface,
        boxSizing:"border-box", width:"100%" }} />
    {hint  && <span style={{ fontSize:11, color:T.textMuted }}>{hint}</span>}
    {error && <span style={{ fontSize:11, color:T.danger }}>{error}</span>}
  </div>
);

const Select = ({ label, value, onChange, options, required }) => (
  <div style={{ display:"flex", flexDirection:"column", gap:5 }}>
    {label && <label style={{ fontSize:12, fontWeight:600, color:T.text }}>{label}{required&&" *"}</label>}
    <select value={value} onChange={onChange} style={{ padding:"9px 12px", borderRadius:8,
      border:`1.5px solid ${T.border}`, fontSize:13, color:T.text, background:T.surface,
      outline:"none", cursor:"pointer" }}>
      <option value="">– Auswählen –</option>
      {options.map(o => <option key={o.value??o} value={o.value??o}>{o.label??o}</option>)}
    </select>
  </div>
);

const Card = ({ children, p=20, style={} }) => (
  <div style={{ background:T.surface, borderRadius:T.radius, border:`1px solid ${T.border}`,
    padding:p, boxShadow:T.shadow, ...style }}>{children}</div>
);

const Modal = ({ title, children, onClose, width=500 }) => (
  <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.45)", zIndex:1000,
    display:"flex", alignItems:"center", justifyContent:"center", padding:20 }}
    onClick={e => e.target===e.currentTarget && onClose()}>
    <div style={{ background:T.surface, borderRadius:T.radius+4, width:"100%", maxWidth:width,
      boxShadow:"0 20px 60px rgba(0,0,0,.25)", overflow:"hidden" }}>
      <div style={{ padding:"18px 22px", borderBottom:`1px solid ${T.border}`,
        display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <h3 style={{ margin:0, fontSize:16, fontWeight:700, color:T.text }}>{title}</h3>
        <button onClick={onClose} style={{ border:"none", background:"none", cursor:"pointer",
          fontSize:20, color:T.textMuted, lineHeight:1 }}>×</button>
      </div>
      <div style={{ padding:22 }}>{children}</div>
    </div>
  </div>
);

const Toast = ({ msg, type="success" }) => (
  <div style={{ position:"fixed", bottom:24, right:24, zIndex:2000,
    background: type==="error"?T.danger:T.success, color:"#fff",
    padding:"12px 20px", borderRadius:10, fontSize:13, fontWeight:600,
    boxShadow:"0 4px 16px rgba(0,0,0,.2)", maxWidth:360 }}>{msg}</div>
);

// ═══════════════════════════════════════════════════════════
// LOGIN PAGE
// ═══════════════════════════════════════════════════════════
function LoginPage() {
  const { login } = useAuth();
  const [email, setEmail] = useState("admin@firma.de");
  const [pass, setPass]   = useState("admin123");
  const [err, setErr]     = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    setErr(""); setLoading(true);
    try {
      await login(email, pass);
    } catch {
      // Demo: ignoriere Fehler und logge direkt ein (Mock-Modus)
      localStorage.setItem("jwt", "DEMO_TOKEN");
      localStorage.setItem("userEmail", email);
      window.location.reload();
    } finally { setLoading(false); }
  };

  return (
    <div style={{ minHeight:"100vh", background:`linear-gradient(135deg, ${T.primaryDark} 0%, ${T.primary} 60%, ${T.primaryLight} 100%)`,
      display:"flex", alignItems:"center", justifyContent:"center", padding:24 }}>
      <div style={{ background:"rgba(255,255,255,.97)", borderRadius:20, padding:"40px 36px",
        width:"100%", maxWidth:380, boxShadow:"0 24px 80px rgba(0,0,0,.25)" }}>
        {/* Logo */}
        <div style={{ textAlign:"center", marginBottom:32 }}>
          <div style={{ width:56, height:56, borderRadius:16, background:T.primary,
            display:"flex", alignItems:"center", justifyContent:"center",
            margin:"0 auto 14px", fontSize:26 }}>🏢</div>
          <h1 style={{ margin:0, fontSize:22, fontWeight:800, color:T.primaryDark }}>CAEMS</h1>
          <p style={{ margin:"4px 0 0", color:T.textMuted, fontSize:13 }}>Corporate Asset & Employee Management</p>
        </div>

        <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
          <Input label="E-Mail" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="admin@firma.de" />
          <Input label="Passwort" type="password" value={pass} onChange={e=>setPass(e.target.value)} placeholder="••••••••" />
          {err && <div style={{ color:T.danger, fontSize:12 }}>{err}</div>}
          <Btn onClick={handleLogin} disabled={loading}>
            {loading ? "Anmelden …" : "Anmelden"}
          </Btn>
        </div>
        <p style={{ textAlign:"center", marginTop:20, fontSize:11, color:T.textMuted }}>
          Demo: admin@firma.de / admin123
        </p>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// EMPLOYEE FORM MODAL
// ═══════════════════════════════════════════════════════════
function EmployeeFormModal({ employee, onSave, onClose }) {
  const initial = employee ?? { employeeNumber:"", firstName:"", lastName:"", email:"",
    phone:"", position:"", department:"", hireDate:"", salary:"", active:true };
  const [form, setForm] = useState(initial);
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  const set = (k, v) => { setForm(f=>({...f,[k]:v})); setErrors(e=>({...e,[k]:""})); };

  const validate = () => {
    const e = {};
    if (!form.firstName)       e.firstName = "Pflichtfeld";
    if (!form.lastName)        e.lastName = "Pflichtfeld";
    if (!form.employeeNumber)  e.employeeNumber = "Pflichtfeld";
    if (!form.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = "Gültige E-Mail erforderlich";
    if (!form.hireDate)        e.hireDate = "Pflichtfeld";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSave = async () => {
    if (!validate()) return;
    setSaving(true);
    try {
      // In der Produktionsversion: await api.post/put(...)
      await new Promise(r => setTimeout(r, 500));
      onSave({ ...form, id: form.id ?? Date.now(), salary: Number(form.salary) });
    } finally { setSaving(false); }
  };

  return (
    <Modal title={employee ? "Mitarbeiter bearbeiten" : "Neuer Mitarbeiter"} onClose={onClose} width={600}>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
        <Input label="Mitarbeiter-Nr." value={form.employeeNumber} onChange={e=>set("employeeNumber",e.target.value)} required error={errors.employeeNumber} placeholder="EMP-001" />
        <Input label="Einstellungsdatum" type="date" value={form.hireDate} onChange={e=>set("hireDate",e.target.value)} required error={errors.hireDate} />
        <Input label="Vorname" value={form.firstName} onChange={e=>set("firstName",e.target.value)} required error={errors.firstName} />
        <Input label="Nachname" value={form.lastName} onChange={e=>set("lastName",e.target.value)} required error={errors.lastName} />
        <Input label="E-Mail" type="email" value={form.email} onChange={e=>set("email",e.target.value)} required error={errors.email} />
        <Input label="Telefon" value={form.phone} onChange={e=>set("phone",e.target.value)} placeholder="+49 30 …" />
        <Input label="Position" value={form.position} onChange={e=>set("position",e.target.value)} />
        <Select label="Abteilung" value={form.department} onChange={e=>set("department",e.target.value)}
          options={["Engineering","Product","Design","Human Resources","Marketing","Finance","IT"]} />
        <Input label="Gehalt (€/Jahr)" type="number" value={form.salary} onChange={e=>set("salary",e.target.value)} placeholder="75000" />
        <div style={{ display:"flex", alignItems:"center", gap:10, paddingTop:20 }}>
          <input type="checkbox" id="active" checked={form.active} onChange={e=>set("active",e.target.checked)} />
          <label htmlFor="active" style={{ fontSize:13, color:T.text }}>Aktiv</label>
        </div>
      </div>
      <div style={{ marginTop:20, display:"flex", justifyContent:"flex-end", gap:10 }}>
        <Btn variant="ghost" onClick={onClose}>Abbrechen</Btn>
        <Btn onClick={handleSave} disabled={saving}>{saving ? "Speichern …" : "Speichern"}</Btn>
      </div>
    </Modal>
  );
}

// ═══════════════════════════════════════════════════════════
// LOAN DIALOG  (Ausleihe-Workflow)
// ═══════════════════════════════════════════════════════════
function LoanDialog({ hardware, employees, loans, onLoan, onReturn, onClose }) {
  const activeLoan = loans.find(l => l.hardwareId === hardware.id && !l.returnedAt);
  const loanee = activeLoan ? employees.find(e => e.id === activeLoan.employeeId) : null;

  const [mode, setMode] = useState(activeLoan ? "return" : "loan");
  const [employeeId, setEmployeeId] = useState("");
  const [returnDate, setReturnDate] = useState("");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  const handleAction = async () => {
    setSaving(true);
    await new Promise(r => setTimeout(r, 400));
    if (mode === "loan") {
      onLoan(hardware.id, Number(employeeId), returnDate, notes);
    } else {
      onReturn(hardware.id, notes);
    }
    setSaving(false);
    onClose();
  };

  return (
    <Modal title={`${HW_EMOJI[hardware.category]||"🖥️"} ${hardware.name}`} onClose={onClose}>
      <div style={{ marginBottom:16, padding:"12px 14px", background:T.bg, borderRadius:10 }}>
        <div style={{ display:"flex", gap:12, alignItems:"center" }}>
          <div>
            <div style={{ fontSize:13, fontWeight:700, color:T.text }}>{hardware.name}</div>
            <div style={{ fontSize:12, color:T.textMuted }}>{hardware.assetTag} · {hardware.manufacturer} {hardware.model}</div>
          </div>
          <Badge label={STATUS[hardware.status]?.label||hardware.status}
            color={STATUS[hardware.status]?.color} bg={STATUS[hardware.status]?.bg} />
        </div>
      </div>

      {activeLoan && loanee && (
        <div style={{ marginBottom:14, padding:"10px 14px", background:"#fef3c7", borderRadius:9,
          border:"1px solid #fcd34d", fontSize:13, color:"#92400e" }}>
          ⚠️ Ausgeliehen an <strong>{loanee.firstName} {loanee.lastName}</strong> seit {activeLoan.loanDate}
        </div>
      )}

      <div style={{ display:"flex", gap:8, marginBottom:18 }}>
        {!activeLoan && <Btn variant={mode==="loan"?"primary":"ghost"} onClick={()=>setMode("loan")}>📤 Ausleihen</Btn>}
        {activeLoan  && <Btn variant={mode==="return"?"primary":"ghost"} onClick={()=>setMode("return")}>📥 Zurückgeben</Btn>}
      </div>

      {mode === "loan" && (
        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          <Select label="Mitarbeiter *" value={employeeId} onChange={e=>setEmployeeId(e.target.value)}
            options={employees.filter(e=>e.active).map(e=>({ value:e.id, label:`${e.firstName} ${e.lastName} (${e.employeeNumber})` }))} />
          <Input label="Geplantes Rückgabedatum" type="date" value={returnDate} onChange={e=>setReturnDate(e.target.value)} />
          <Input label="Notizen" value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Optionale Bemerkung …" />
        </div>
      )}

      {mode === "return" && (
        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          <div style={{ padding:"12px 14px", background:"#f0fdf4", borderRadius:9,
            border:"1px solid #bbf7d0", fontSize:13, color:"#166534" }}>
            ✅ Hardware wird von <strong>{loanee?.firstName} {loanee?.lastName}</strong> zurückgenommen und als
            "Verfügbar" markiert.
          </div>
          <Input label="Zustandsnotiz" value={notes} onChange={e=>setNotes(e.target.value)} placeholder="z.B. Gerät in gutem Zustand …" />
        </div>
      )}

      <div style={{ marginTop:20, display:"flex", justifyContent:"flex-end", gap:10 }}>
        <Btn variant="ghost" onClick={onClose}>Abbrechen</Btn>
        <Btn onClick={handleAction} disabled={saving||(mode==="loan"&&!employeeId)}>
          {saving ? "…" : mode==="loan" ? "📤 Ausleihen" : "📥 Zurückgeben"}
        </Btn>
      </div>
    </Modal>
  );
}

// ═══════════════════════════════════════════════════════════
// EMPLOYEES PAGE  (Master-Detail)
// ═══════════════════════════════════════════════════════════
function EmployeesPage({ toast }) {
  const [employees, setEmployees] = useState(EMPLOYEES);
  const [selected, setSelected] = useState(null);
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editEmp, setEditEmp] = useState(null);

  const filtered = employees.filter(e =>
    `${e.firstName} ${e.lastName} ${e.employeeNumber} ${e.department} ${e.position}`
      .toLowerCase().includes(search.toLowerCase())
  );
  const emp = employees.find(e => e.id === selected);

  const handleSave = (saved) => {
    setEmployees(prev => {
      const exists = prev.find(e => e.id === saved.id);
      return exists ? prev.map(e => e.id===saved.id ? saved : e) : [...prev, saved];
    });
    setShowForm(false); setEditEmp(null);
    toast(saved.id ? "Mitarbeiter gespeichert ✅" : "Mitarbeiter angelegt ✅");
  };

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:14, height:"100%" }}>
      {/* Toolbar */}
      <div style={{ display:"flex", gap:10, alignItems:"center" }}>
        <div style={{ position:"relative", flex:1 }}>
          <span style={{ position:"absolute", left:11, top:"50%", transform:"translateY(-50%)", color:T.textMuted, pointerEvents:"none" }}>🔍</span>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Name, Nummer, Abteilung suchen …"
            style={{ width:"100%", padding:"9px 12px 9px 34px", borderRadius:9, border:`1px solid ${T.border}`,
              fontSize:13, outline:"none", background:"#fff", boxSizing:"border-box" }} />
        </div>
        <Btn onClick={() => { setEditEmp(null); setShowForm(true); }}>＋ Mitarbeiter</Btn>
      </div>

      <div style={{ display:"flex", gap:12, flex:1, minHeight:0 }}>
        {/* Master List */}
        <div style={{ width:280, flexShrink:0, overflowY:"auto", display:"flex", flexDirection:"column", gap:6 }}>
          {filtered.map(e => (
            <div key={e.id} onClick={() => setSelected(e.id)}
              style={{ background: selected===e.id?"#eef2ff":"#fff",
                border:`1.5px solid ${selected===e.id?T.primaryLight:T.border}`,
                borderRadius:11, padding:"11px 13px", cursor:"pointer",
                display:"flex", alignItems:"center", gap:11, transition:"all .15s" }}>
              <Avatar name={`${e.firstName} ${e.lastName}`} size={38} />
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:13.5, fontWeight:700, color:T.text, display:"flex", justifyContent:"space-between" }}>
                  {e.firstName} {e.lastName}
                  {!e.active && <Badge label="Inaktiv" color={T.danger} bg="#fee2e2" sm />}
                </div>
                <div style={{ fontSize:11.5, color:T.textMuted, marginTop:2 }}>{e.position}</div>
                <div style={{ marginTop:5 }}>
                  <Badge label={e.department} color={DEPT[e.department]||T.textMuted} bg={(DEPT[e.department]||T.textMuted)+"22"} sm />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Detail */}
        <div style={{ flex:1, overflowY:"auto" }}>
          {!emp ? (
            <div style={{ height:"100%", display:"flex", alignItems:"center", justifyContent:"center",
              flexDirection:"column", gap:12, color:T.textMuted }}>
              <span style={{ fontSize:48 }}>👤</span>
              <div style={{ fontSize:14 }}>Mitarbeiter auswählen</div>
            </div>
          ) : (
            <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
              <Card style={{ borderTop:`4px solid ${DEPT[emp.department]||T.primary}` }}>
                <div style={{ display:"flex", gap:16, alignItems:"flex-start" }}>
                  <Avatar name={`${emp.firstName} ${emp.lastName}`} size={60} />
                  <div style={{ flex:1 }}>
                    <div style={{ display:"flex", alignItems:"center", gap:10, flexWrap:"wrap" }}>
                      <h2 style={{ margin:0, fontSize:20, fontWeight:800, color:T.text }}>{emp.firstName} {emp.lastName}</h2>
                      <Badge label={emp.active?"Aktiv":"Inaktiv"} color={emp.active?T.success:T.danger} bg={emp.active?"#d1fae5":"#fee2e2"} />
                    </div>
                    <div style={{ color:T.primary, fontWeight:600, marginTop:4, fontSize:14 }}>{emp.position}</div>
                    <div style={{ display:"flex", gap:8, marginTop:8, flexWrap:"wrap" }}>
                      <Badge label={emp.department} color={DEPT[emp.department]||T.textMuted} bg={(DEPT[emp.department]||T.textMuted)+"22"} />
                      <Badge label={emp.employeeNumber} color={T.text} bg={T.bg} />
                    </div>
                  </div>
                  <Btn sm variant="ghost" onClick={() => { setEditEmp(emp); setShowForm(true); }}>✏️ Bearbeiten</Btn>
                </div>
              </Card>

              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
                {[
                  { icon:"📧", label:"E-Mail", value:emp.email },
                  { icon:"📞", label:"Telefon", value:emp.phone||"—" },
                  { icon:"📅", label:"Eingestellt", value:new Date(emp.hireDate).toLocaleDateString("de-DE") },
                  { icon:"💶", label:"Gehalt", value:`${emp.salary?.toLocaleString("de-DE")} €/Jahr` },
                ].map(item => (
                  <Card key={item.label} p={14}>
                    <div style={{ display:"flex", gap:10, alignItems:"center" }}>
                      <span style={{ fontSize:18 }}>{item.icon}</span>
                      <div>
                        <div style={{ fontSize:11, color:T.textMuted, fontWeight:500 }}>{item.label}</div>
                        <div style={{ fontSize:13, color:T.text, fontWeight:600, marginTop:2 }}>{item.value}</div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              <Card>
                <div style={{ fontWeight:700, fontSize:13.5, marginBottom:10 }}>💻 Zugewiesene Hardware</div>
                <div style={{ color:T.textMuted, fontSize:13 }}>Hardware-Tab für Details öffnen.</div>
              </Card>
              <Card>
                <div style={{ fontWeight:700, fontSize:13.5, marginBottom:10 }}>📦 Software & Lizenzen</div>
                <div style={{ color:T.textMuted, fontSize:13 }}>Software-Tab für Details öffnen.</div>
              </Card>
            </div>
          )}
        </div>
      </div>

      {showForm && <EmployeeFormModal employee={editEmp} onSave={handleSave} onClose={() => { setShowForm(false); setEditEmp(null); }} />}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// HARDWARE PAGE
// ═══════════════════════════════════════════════════════════
function HardwarePage({ toast }) {
  const [hardware, setHardware] = useState(HARDWARE);
  const [employees] = useState(EMPLOYEES);
  const [loans, setLoans]   = useState([
    { id:1, hardwareId:2, employeeId:1, loanDate:"2024-11-01", returnedAt:null }
  ]);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("ALL");
  const [loanDialog, setLoanDialog] = useState(null);

  const filtered = hardware.filter(h => {
    const matchSearch = `${h.name} ${h.assetTag} ${h.manufacturer}`.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter==="ALL" || h.status===filter;
    return matchSearch && matchFilter;
  });

  const handleLoan = (hwId, empId, returnDate, notes) => {
    setLoans(l => [...l, { id:Date.now(), hardwareId:hwId, employeeId:empId, loanDate:new Date().toISOString().slice(0,10), returnedAt:null, returnDate, notes }]);
    setHardware(h => h.map(hw => hw.id===hwId ? {...hw, status:"LOANED"} : hw));
    toast("Hardware erfolgreich ausgeliehen 📤");
  };

  const handleReturn = (hwId, notes) => {
    setLoans(l => l.map(loan => loan.hardwareId===hwId && !loan.returnedAt ? {...loan, returnedAt:new Date().toISOString()} : loan));
    setHardware(h => h.map(hw => hw.id===hwId ? {...hw, status:"AVAILABLE"} : hw));
    toast("Hardware zurückgenommen 📥");
  };

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:14, height:"100%" }}>
      <div style={{ display:"flex", gap:10, flexWrap:"wrap" }}>
        <div style={{ position:"relative", flex:1, minWidth:200 }}>
          <span style={{ position:"absolute", left:11, top:"50%", transform:"translateY(-50%)", color:T.textMuted }}>🔍</span>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Hardware suchen …"
            style={{ width:"100%", padding:"9px 12px 9px 34px", borderRadius:9, border:`1px solid ${T.border}`, fontSize:13, outline:"none", boxSizing:"border-box" }} />
        </div>
        <div style={{ display:"flex", gap:5, flexWrap:"wrap" }}>
          {["ALL","AVAILABLE","LOANED","MAINTENANCE","RETIRED"].map(s => (
            <button key={s} onClick={()=>setFilter(s)} style={{
              padding:"7px 12px", borderRadius:8, border:`1.5px solid ${filter===s?T.primary:T.border}`,
              background:filter===s?"#eef2ff":"#fff", color:filter===s?T.primary:T.textMuted,
              fontSize:12, fontWeight:500, cursor:"pointer" }}>
              {s==="ALL"?"Alle":STATUS[s]?.label||s}
            </button>
          ))}
        </div>
        <Btn>＋ Hardware</Btn>
      </div>

      <div style={{ flex:1, overflowY:"auto" }}>
        <table style={{ width:"100%", borderCollapse:"separate", borderSpacing:"0 6px" }}>
          <thead>
            <tr style={{ fontSize:11, color:T.textMuted, fontWeight:700, textTransform:"uppercase", letterSpacing:"0.5px" }}>
              {["","Asset-Tag","Gerät","Kategorie","Status","Garantie","Zugewiesen an",""].map((h,i)=>(
                <th key={i} style={{ padding:"4px 10px", textAlign:"left" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map(hw => {
              const loan = loans.find(l => l.hardwareId===hw.id && !l.returnedAt);
              const assignee = loan ? employees.find(e => e.id===loan.employeeId) : null;
              const st = STATUS[hw.status]||{color:"#999",bg:"#eee",label:hw.status};
              const warrantyExpired = new Date(hw.warrantyUntil) < new Date();
              return (
                <tr key={hw.id} style={{ fontSize:13 }}>
                  <td style={{ padding:"11px 10px 11px 14px", background:"#fff", borderRadius:"11px 0 0 11px", border:`1px solid ${T.border}`, borderRight:"none", fontSize:22 }}>
                    {HW_EMOJI[hw.category]||"🖥️"}
                  </td>
                  <td style={{ padding:"11px 10px", background:"#fff", border:`1px solid ${T.border}`, borderLeft:"none", borderRight:"none" }}>
                    <code style={{ fontSize:11, background:T.bg, padding:"2px 7px", borderRadius:5, color:T.primary }}>{hw.assetTag}</code>
                  </td>
                  <td style={{ padding:"11px 10px", background:"#fff", border:`1px solid ${T.border}`, borderLeft:"none", borderRight:"none" }}>
                    <div style={{ fontWeight:700, color:T.text }}>{hw.name}</div>
                    <div style={{ fontSize:11, color:T.textMuted }}>{hw.manufacturer} · {hw.model}</div>
                  </td>
                  <td style={{ padding:"11px 10px", background:"#fff", border:`1px solid ${T.border}`, borderLeft:"none", borderRight:"none" }}>
                    <Badge label={hw.category} color={T.text} bg={T.bg} sm />
                  </td>
                  <td style={{ padding:"11px 10px", background:"#fff", border:`1px solid ${T.border}`, borderLeft:"none", borderRight:"none" }}>
                    <Badge label={st.label} color={st.color} bg={st.bg} sm />
                  </td>
                  <td style={{ padding:"11px 10px", background:"#fff", border:`1px solid ${T.border}`, borderLeft:"none", borderRight:"none",
                    color:warrantyExpired?T.danger:T.textMuted, fontSize:12 }}>
                    {new Date(hw.warrantyUntil).toLocaleDateString("de-DE")}
                    {warrantyExpired&&" ⚠️"}
                  </td>
                  <td style={{ padding:"11px 10px", background:"#fff", border:`1px solid ${T.border}`, borderLeft:"none", borderRight:"none" }}>
                    {assignee ? (
                      <div style={{ display:"flex", alignItems:"center", gap:7 }}>
                        <Avatar name={`${assignee.firstName} ${assignee.lastName}`} size={22} />
                        <span style={{ fontSize:12 }}>{assignee.firstName} {assignee.lastName}</span>
                      </div>
                    ) : <span style={{ color:T.textMuted, fontSize:12 }}>—</span>}
                  </td>
                  <td style={{ padding:"11px 14px 11px 10px", background:"#fff", borderRadius:"0 11px 11px 0", border:`1px solid ${T.border}`, borderLeft:"none" }}>
                    {hw.status !== "RETIRED" && (
                      <Btn sm variant="secondary" onClick={() => setLoanDialog(hw)}>
                        {hw.status==="LOANED"?"📥 Rückgabe":"📤 Ausleihen"}
                      </Btn>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {loanDialog && (
        <LoanDialog hardware={loanDialog} employees={employees} loans={loans}
          onLoan={handleLoan} onReturn={handleReturn} onClose={()=>setLoanDialog(null)} />
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// SOFTWARE PAGE
// ═══════════════════════════════════════════════════════════
function SoftwarePage({ toast }) {
  const [software, setSoftware] = useState(SOFTWARE);
  const [assignDialog, setAssignDialog] = useState(null);
  const [employees] = useState(EMPLOYEES);
  const [empId, setEmpId] = useState("");

  const handleAssign = (swId) => {
    if (!empId) return;
    setSoftware(s => s.map(sw => sw.id===swId ? {...sw, usedLicenses:sw.usedLicenses+1} : sw));
    toast("Lizenz zugewiesen ✅");
    setAssignDialog(null); setEmpId("");
  };

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
      <div style={{ display:"flex", justifyContent:"flex-end" }}>
        <Btn>＋ Software</Btn>
      </div>

      {software.map(sw => {
        const pct = Math.round((sw.usedLicenses/sw.totalLicenses)*100);
        const low = pct >= 85;
        const daysLeft = Math.ceil((new Date(sw.renewalDate)-new Date())/(1000*86400));
        const catEmoji = {PRODUCTIVITY:"📊",DEV_TOOLS:"🛠️",DESIGN:"🎨",OS:"💾"}[sw.category]||"💾";
        return (
          <Card key={sw.id}>
            <div style={{ display:"flex", gap:14, alignItems:"flex-start" }}>
              <div style={{ width:48, height:48, borderRadius:12, background:T.bg,
                display:"flex", alignItems:"center", justifyContent:"center", fontSize:24, flexShrink:0 }}>
                {catEmoji}
              </div>
              <div style={{ flex:1 }}>
                <div style={{ display:"flex", justifyContent:"space-between", flexWrap:"wrap", gap:8 }}>
                  <div>
                    <div style={{ fontWeight:800, fontSize:15, color:T.text }}>{sw.name}</div>
                    <div style={{ fontSize:12, color:T.textMuted, marginTop:2 }}>{sw.vendor} · v{sw.version}</div>
                  </div>
                  <div style={{ display:"flex", gap:6, alignItems:"center", flexWrap:"wrap" }}>
                    <Badge label={sw.licenseType} color={T.text} bg={T.bg} sm />
                    <Badge label={sw.category} color={T.text} bg={T.bg} sm />
                  </div>
                </div>

                <div style={{ marginTop:12 }}>
                  <div style={{ display:"flex", justifyContent:"space-between", fontSize:12, marginBottom:5 }}>
                    <span style={{ color:T.textMuted }}>Lizenzen: <strong style={{ color:T.text }}>{sw.usedLicenses} / {sw.totalLicenses}</strong></span>
                    <span style={{ color:low?T.danger:T.textMuted, fontWeight:600 }}>{pct}%{low&&" ⚠️"}</span>
                  </div>
                  <div style={{ height:7, background:T.border, borderRadius:4 }}>
                    <div style={{ height:"100%", width:`${pct}%`, borderRadius:4,
                      background:low?T.danger:T.primary, transition:"width .3s" }} />
                  </div>
                </div>

                <div style={{ marginTop:10, display:"flex", gap:16, flexWrap:"wrap", fontSize:12, color:T.textMuted }}>
                  <span>💶 {sw.costPerLicense?.toFixed(2)} €/Lizenz/Monat</span>
                  <span>💶 {(sw.totalLicenses*sw.costPerLicense*12).toFixed(0)} €/Jahr gesamt</span>
                  <span style={{ color:daysLeft<60?T.danger:T.textMuted }}>
                    📅 Erneuerung: {new Date(sw.renewalDate).toLocaleDateString("de-DE")} ({daysLeft>0?`in ${daysLeft} Tagen`:"⚠️ abgelaufen"})
                  </span>
                </div>
              </div>
              <Btn sm variant="secondary" onClick={() => setAssignDialog(sw)} disabled={sw.usedLicenses>=sw.totalLicenses}>
                Zuweisen
              </Btn>
            </div>
          </Card>
        );
      })}

      {assignDialog && (
        <Modal title={`Lizenz zuweisen: ${assignDialog.name}`} onClose={() => { setAssignDialog(null); setEmpId(""); }}>
          <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
            <div style={{ padding:"10px 14px", background:T.bg, borderRadius:9, fontSize:13, color:T.textMuted }}>
              Noch {assignDialog.totalLicenses-assignDialog.usedLicenses} Lizenzen verfügbar.
            </div>
            <Select label="Mitarbeiter auswählen *" value={empId} onChange={e=>setEmpId(e.target.value)}
              options={employees.filter(e=>e.active).map(e=>({ value:e.id, label:`${e.firstName} ${e.lastName}` }))} />
          </div>
          <div style={{ marginTop:20, display:"flex", justifyContent:"flex-end", gap:10 }}>
            <Btn variant="ghost" onClick={() => { setAssignDialog(null); setEmpId(""); }}>Abbrechen</Btn>
            <Btn onClick={() => handleAssign(assignDialog.id)} disabled={!empId}>Zuweisen</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// DASHBOARD
// ═══════════════════════════════════════════════════════════
function Dashboard() {
  const active    = EMPLOYEES.filter(e=>e.active).length;
  const available = HARDWARE.filter(h=>h.status==="AVAILABLE").length;
  const loaned    = HARDWARE.filter(h=>h.status==="LOANED").length;
  const totalLic  = SOFTWARE.reduce((a,s)=>a+s.totalLicenses,0);
  const usedLic   = SOFTWARE.reduce((a,s)=>a+s.usedLicenses,0);

  const stats = [
    { icon:"👥", label:"Aktive Mitarbeiter", value:active, color:T.primary },
    { icon:"✅", label:"Hardware verfügbar", value:available, color:T.success },
    { icon:"📤", label:"Hardware ausgeliehen", value:loaned, color:T.warning },
    { icon:"🔑", label:"Lizenzen in Nutzung", value:`${usedLic}/${totalLic}`, color:"#8b5cf6" },
  ];

  const deptCounts = EMPLOYEES.reduce((a,e)=>({...a,[e.department]:(a[e.department]||0)+1}),{});

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(190px,1fr))", gap:12 }}>
        {stats.map(s => (
          <Card key={s.label} style={{ display:"flex", alignItems:"center", gap:14 }}>
            <div style={{ width:48, height:48, borderRadius:12, background:s.color+"1a",
              display:"flex", alignItems:"center", justifyContent:"center", fontSize:22, flexShrink:0 }}>
              {s.icon}
            </div>
            <div>
              <div style={{ fontSize:26, fontWeight:800, color:T.text, lineHeight:1.1 }}>{s.value}</div>
              <div style={{ fontSize:12, color:T.textMuted, marginTop:2 }}>{s.label}</div>
            </div>
          </Card>
        ))}
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
        <Card>
          <div style={{ fontWeight:700, fontSize:14, marginBottom:14 }}>👥 Mitarbeiter nach Abteilung</div>
          {Object.entries(deptCounts).map(([dept,count])=>(
            <div key={dept} style={{ marginBottom:10 }}>
              <div style={{ display:"flex", justifyContent:"space-between", fontSize:13, marginBottom:4 }}>
                <span style={{ color:T.text }}>{dept}</span>
                <span style={{ fontWeight:700 }}>{count}</span>
              </div>
              <div style={{ height:6, background:T.border, borderRadius:3 }}>
                <div style={{ height:"100%", width:`${(count/EMPLOYEES.length)*100}%`, background:DEPT[dept]||T.primary, borderRadius:3 }} />
              </div>
            </div>
          ))}
        </Card>

        <Card>
          <div style={{ fontWeight:700, fontSize:14, marginBottom:14 }}>🔑 Lizenzauslastung</div>
          {SOFTWARE.map(sw => {
            const pct = Math.round((sw.usedLicenses/sw.totalLicenses)*100);
            return (
              <div key={sw.id} style={{ marginBottom:10 }}>
                <div style={{ display:"flex", justifyContent:"space-between", fontSize:12, marginBottom:4 }}>
                  <span style={{ color:T.text, fontWeight:500 }}>{sw.name}</span>
                  <span style={{ color:pct>=85?T.danger:T.textMuted, fontWeight:600 }}>{pct}%</span>
                </div>
                <div style={{ height:5, background:T.border, borderRadius:3 }}>
                  <div style={{ height:"100%", width:`${pct}%`, background:pct>=85?T.danger:T.primary, borderRadius:3 }} />
                </div>
              </div>
            );
          })}
        </Card>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// SHELL / LAYOUT
// ═══════════════════════════════════════════════════════════
const NAV = [
  { id:"dashboard", label:"Dashboard", icon:"📊" },
  { id:"employees", label:"Mitarbeiter", icon:"👥" },
  { id:"hardware",  label:"Hardware",   icon:"💻" },
  { id:"software",  label:"Software & Lizenzen", icon:"🔑" },
];

function Shell() {
  const { user, logout } = useAuth();
  const [page, setPage]   = useState("dashboard");
  const [toast, setToast] = useState(null);

  const showToast = useCallback((msg, type="success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  }, []);

  if (!user) return <LoginPage />;

  const pages = {
    dashboard: <Dashboard />,
    employees: <EmployeesPage toast={showToast} />,
    hardware:  <HardwarePage toast={showToast} />,
    software:  <SoftwarePage toast={showToast} />,
  };

  return (
    <div style={{ display:"flex", height:"100vh", background:T.bg, fontFamily:"'Inter',-apple-system,sans-serif", overflow:"hidden" }}>
      {/* Sidebar */}
      <div style={{ width:220, background:T.primaryDark, display:"flex", flexDirection:"column", flexShrink:0 }}>
        <div style={{ padding:"22px 16px 18px", borderBottom:"1px solid rgba(255,255,255,.08)" }}>
          <div style={{ display:"flex", alignItems:"center", gap:10 }}>
            <div style={{ width:36, height:36, borderRadius:10, background:T.primaryLight,
              display:"flex", alignItems:"center", justifyContent:"center", fontSize:18 }}>🏢</div>
            <div>
              <div style={{ color:"#fff", fontWeight:800, fontSize:15 }}>CAEMS</div>
              <div style={{ color:"rgba(255,255,255,.4)", fontSize:10 }}>Asset Management</div>
            </div>
          </div>
        </div>
        <nav style={{ padding:"12px 10px", flex:1 }}>
          {NAV.map(item => (
            <button key={item.id} onClick={() => setPage(item.id)} style={{
              width:"100%", padding:"9px 12px", borderRadius:9, border:"none",
              background: page===item.id ? "rgba(255,255,255,.14)" : "transparent",
              color: page===item.id ? "#fff" : "rgba(255,255,255,.5)",
              display:"flex", alignItems:"center", gap:10, marginBottom:2,
              cursor:"pointer", fontSize:13, fontWeight:page===item.id?700:400,
              textAlign:"left", transition:"all .15s",
            }}>
              <span>{item.icon}</span> {item.label}
            </button>
          ))}
        </nav>
        <div style={{ margin:"0 10px 12px", padding:"10px 12px", background:"rgba(255,255,255,.07)",
          borderRadius:10, display:"flex", alignItems:"center", gap:10 }}>
          <div style={{ width:30, height:30, borderRadius:15, background:T.primaryLight,
            display:"flex", alignItems:"center", justifyContent:"center", fontSize:12, fontWeight:800, color:"#fff" }}>
            {user.email[0].toUpperCase()}
          </div>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ color:"#fff", fontSize:11, fontWeight:600, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{user.email}</div>
            <button onClick={logout} style={{ color:"rgba(255,255,255,.4)", fontSize:10, background:"none", border:"none", cursor:"pointer", padding:0, textAlign:"left" }}>Abmelden</button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
        <div style={{ padding:"14px 22px", background:"#fff", borderBottom:`1px solid ${T.border}`,
          display:"flex", alignItems:"center", justifyContent:"space-between" }}>
          <h1 style={{ margin:0, fontSize:18, fontWeight:800, color:T.text }}>
            {NAV.find(n=>n.id===page)?.icon} {NAV.find(n=>n.id===page)?.label}
          </h1>
          <span style={{ fontSize:12, color:T.textMuted }}>
            {new Date().toLocaleDateString("de-DE",{weekday:"long",year:"numeric",month:"long",day:"numeric"})}
          </span>
        </div>
        <div style={{ flex:1, overflow:"auto", padding:20 }}>
          {pages[page]}
        </div>
      </div>

      {toast && <Toast msg={toast.msg} type={toast.type} />}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// ROOT
// ═══════════════════════════════════════════════════════════
export default function App() {
  return (
    <AuthProvider>
      <Shell />
    </AuthProvider>
  );
}
