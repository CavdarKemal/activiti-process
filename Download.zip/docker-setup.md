# CAEMS – Docker Setup (vollständig)

## Dateistruktur
```
caems/
├── docker-compose.yml          ← Haupt-Compose (Produktion)
├── docker-compose.dev.yml      ← Dev-Overlay (Hot-Reload)
├── docker-compose.test.yml     ← Test-Umgebung
├── .env.example                ← Beispiel-Umgebungsvariablen
├── .env                        ← Deine echten Werte (nicht ins Git!)
├── backend/
│   └── Dockerfile
├── frontend/
│   ├── Dockerfile
│   └── nginx/
│       └── default.conf
└── postgres/
    └── init/
        └── 01-create-user.sql
```

---

## docker-compose.yml  (Produktion)
```yaml
version: "3.9"

services:

  # ── PostgreSQL ──────────────────────────────────────────
  postgres:
    image: postgres:16-alpine
    container_name: caems-postgres
    restart: unless-stopped
    environment:
      POSTGRES_DB:       ${POSTGRES_DB:-caems}
      POSTGRES_USER:     ${POSTGRES_USER:-caems}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:-caems_secret}
    volumes:
      - pgdata:/var/lib/postgresql/data
      - ./postgres/init:/docker-entrypoint-initdb.d:ro
    ports:
      - "5432:5432"          # nur für direkten DB-Zugriff; in Prod entfernen
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER:-caems} -d ${POSTGRES_DB:-caems}"]
      interval: 10s
      timeout: 5s
      retries: 5
      start_period: 30s
    networks:
      - caems-net

  # ── Backend (Spring Boot) ───────────────────────────────
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
      args:
        JAR_FILE: target/caems-backend-1.0.0.jar
    container_name: caems-backend
    restart: unless-stopped
    depends_on:
      postgres:
        condition: service_healthy
    environment:
      SPRING_DATASOURCE_URL:      jdbc:postgresql://postgres:5432/${POSTGRES_DB:-caems}
      SPRING_DATASOURCE_USERNAME: ${POSTGRES_USER:-caems}
      SPRING_DATASOURCE_PASSWORD: ${POSTGRES_PASSWORD:-caems_secret}
      SPRING_JPA_HIBERNATE_DDL_AUTO: validate
      SPRING_FLYWAY_ENABLED:      "true"
      APP_JWT_SECRET:             ${JWT_SECRET:-AendereIchInProduktionUnbedingt32Zeichen!}
      APP_JWT_EXPIRATION_MS:      ${JWT_EXPIRATION_MS:-86400000}
      APP_UPLOAD_DIR:             /app/uploads
      JAVA_OPTS:                  "-Xms256m -Xmx512m"
    volumes:
      - uploads:/app/uploads
    ports:
      - "8080:8080"
    healthcheck:
      test: ["CMD-SHELL", "curl -f http://localhost:8080/actuator/health || exit 1"]
      interval: 15s
      timeout: 5s
      retries: 5
      start_period: 60s
    networks:
      - caems-net

  # ── Frontend (React + nginx) ────────────────────────────
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
      args:
        VITE_API_BASE_URL: ${VITE_API_BASE_URL:-http://localhost:8080/api/v1}
    container_name: caems-frontend
    restart: unless-stopped
    depends_on:
      backend:
        condition: service_healthy
    ports:
      - "3000:80"
    networks:
      - caems-net

volumes:
  pgdata:
    name: caems-pgdata
  uploads:
    name: caems-uploads

networks:
  caems-net:
    name: caems-network
    driver: bridge
```

---

## docker-compose.dev.yml  (Dev-Overlay – Hot-Reload)
```yaml
# Verwendung:
#   docker compose -f docker-compose.yml -f docker-compose.dev.yml up

version: "3.9"

services:

  postgres:
    ports:
      - "5432:5432"   # immer exponiert in Dev

  backend:
    build:
      target: development   # nutzt Dev-Stage im Dockerfile
    environment:
      SPRING_JPA_SHOW_SQL:                  "true"
      SPRING_JPA_PROPERTIES_HIBERNATE_FORMAT_SQL: "true"
      LOGGING_LEVEL_COM_CAEMS:              DEBUG
      LOGGING_LEVEL_ORG_SPRINGFRAMEWORK_SECURITY: DEBUG
    volumes:
      - ./backend/src:/app/src:delegated    # Live-Reload via Spring DevTools
      - ~/.m2:/root/.m2:cached              # Maven-Cache
    ports:
      - "8080:8080"
      - "5005:5005"   # Remote-Debug-Port

  frontend:
    build: {}
    image: node:20-alpine
    working_dir: /app
    command: sh -c "npm install && npm run dev -- --host 0.0.0.0"
    volumes:
      - ./frontend:/app:delegated
      - /app/node_modules
    ports:
      - "5173:5173"   # Vite Dev-Server
    environment:
      VITE_API_BASE_URL: http://localhost:8080/api/v1
```

---

## docker-compose.test.yml  (Integrationstests mit Testcontainers-Alternative)
```yaml
# Verwendung:
#   docker compose -f docker-compose.test.yml up --abort-on-container-exit

version: "3.9"

services:

  postgres-test:
    image: postgres:16-alpine
    container_name: caems-postgres-test
    environment:
      POSTGRES_DB:       caems_test
      POSTGRES_USER:     test
      POSTGRES_PASSWORD: test
    ports:
      - "5433:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U test -d caems_test"]
      interval: 5s
      retries: 10
    networks:
      - test-net

  backend-test:
    build:
      context: ./backend
      dockerfile: Dockerfile
      target: test
    container_name: caems-backend-test
    depends_on:
      postgres-test:
        condition: service_healthy
    environment:
      SPRING_DATASOURCE_URL:      jdbc:postgresql://postgres-test:5432/caems_test
      SPRING_DATASOURCE_USERNAME: test
      SPRING_DATASOURCE_PASSWORD: test
      SPRING_FLYWAY_ENABLED:      "true"
    command: mvn test -Dspring.profiles.active=test
    volumes:
      - ~/.m2:/root/.m2:cached
    networks:
      - test-net

networks:
  test-net:
    driver: bridge
```

---

## backend/Dockerfile  (Multi-Stage)
```dockerfile
# ── Stage 1: Build ──────────────────────────────────────────────────────────
FROM maven:3.9-eclipse-temurin-21 AS build

WORKDIR /app

# Abhängigkeiten cachen (nur pom.xml zuerst kopieren)
COPY pom.xml .
RUN mvn dependency:go-offline -B

# Quellcode kopieren und bauen (Tests überspringen – laufen separat)
COPY src ./src
RUN mvn package -DskipTests -B

# ── Stage 2: Test ───────────────────────────────────────────────────────────
FROM build AS test
# Tests laufen hier gegen externe DB (docker-compose.test.yml)
CMD ["mvn", "test", "-B"]

# ── Stage 3: Development ────────────────────────────────────────────────────
FROM eclipse-temurin:21-jre AS development
WORKDIR /app
COPY --from=build /app/target/caems-backend-1.0.0.jar app.jar

# Spring DevTools für Hot-Reload
ENV JAVA_OPTS="-Xms128m -Xmx256m -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005"
EXPOSE 8080 5005
ENTRYPOINT ["sh", "-c", "java $JAVA_OPTS -jar app.jar"]

# ── Stage 4: Production ─────────────────────────────────────────────────────
FROM eclipse-temurin:21-jre-alpine AS production

# Sicherheit: kein Root
RUN addgroup -S caems && adduser -S caems -G caems
WORKDIR /app

# Nur das fertige JAR kopieren
COPY --from=build /app/target/caems-backend-1.0.0.jar app.jar
RUN chown caems:caems app.jar

# Upload-Verzeichnis anlegen
RUN mkdir -p /app/uploads && chown caems:caems /app/uploads
VOLUME ["/app/uploads"]

USER caems
EXPOSE 8080

# Health-Check via Spring Actuator
HEALTHCHECK --interval=15s --timeout=5s --start-period=60s --retries=3 \
  CMD wget -qO- http://localhost:8080/actuator/health || exit 1

ENV JAVA_OPTS="-Xms256m -Xmx512m -XX:+UseContainerSupport -XX:MaxRAMPercentage=75"
ENTRYPOINT ["sh", "-c", "java $JAVA_OPTS -jar app.jar"]
```

---

## frontend/Dockerfile  (Multi-Stage mit nginx)
```dockerfile
# ── Stage 1: Build ──────────────────────────────────────────────────────────
FROM node:20-alpine AS build

WORKDIR /app

# Abhängigkeiten cachen
COPY package*.json ./
RUN npm ci --frozen-lockfile

# Quellcode kopieren
COPY . .

# Build-Argument für API-URL
ARG VITE_API_BASE_URL=http://localhost:8080/api/v1
ENV VITE_API_BASE_URL=$VITE_API_BASE_URL

# Produktions-Build
RUN npm run build

# ── Stage 2: Serve mit nginx ─────────────────────────────────────────────────
FROM nginx:1.25-alpine AS production

# Sicherheits-Header & optimierte nginx-Konfiguration
COPY nginx/default.conf /etc/nginx/conf.d/default.conf

# Statische Dateien aus Build-Stage
COPY --from=build /app/dist /usr/share/nginx/html

EXPOSE 80

HEALTHCHECK --interval=10s --timeout=3s --retries=3 \
  CMD wget -qO- http://localhost:80/health || exit 1

CMD ["nginx", "-g", "daemon off;"]
```

---

## frontend/nginx/default.conf
```nginx
server {
    listen       80;
    server_name  _;
    root         /usr/share/nginx/html;
    index        index.html;

    # Sicherheits-Header
    add_header X-Frame-Options         "SAMEORIGIN"   always;
    add_header X-Content-Type-Options  "nosniff"      always;
    add_header X-XSS-Protection        "1; mode=block" always;
    add_header Referrer-Policy         "strict-origin-when-cross-origin" always;

    # Gzip-Komprimierung
    gzip on;
    gzip_types text/plain text/css application/json application/javascript
               text/xml application/xml application/xml+rss text/javascript;
    gzip_min_length 1024;

    # Statische Assets – lang cachen
    location ~* \.(js|css|png|jpg|jpeg|svg|ico|woff2?)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        try_files $uri =404;
    }

    # Health-Check-Endpunkt für Docker
    location /health {
        return 200 "OK";
        add_header Content-Type text/plain;
    }

    # API-Proxy → Backend (verhindert CORS-Probleme in Prod)
    location /api/ {
        proxy_pass         http://backend:8080;
        proxy_set_header   Host              $host;
        proxy_set_header   X-Real-IP         $remote_addr;
        proxy_set_header   X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;
        proxy_read_timeout 60s;
        proxy_connect_timeout 10s;
    }

    # React Router – alle Routen auf index.html
    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

---

## postgres/init/01-create-user.sql
```sql
-- Wird nur beim ersten Start ausgeführt (frisches Volume)
-- Hier können extra Rollen, Extensions etc. angelegt werden

-- pgcrypto für UUID-Generierung (optional)
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Read-Only Rolle für Reporting / Monitoring
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'caems_readonly') THEN
    CREATE ROLE caems_readonly;
  END IF;
END$$;

GRANT CONNECT ON DATABASE caems TO caems_readonly;
GRANT USAGE ON SCHEMA public TO caems_readonly;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO caems_readonly;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO caems_readonly;
```

---

## .env.example
```dotenv
# ── Datenbank ─────────────────────────────────────────────
POSTGRES_DB=caems
POSTGRES_USER=caems
POSTGRES_PASSWORD=AENDERN_IN_PRODUKTION

# ── Backend / JWT ──────────────────────────────────────────
JWT_SECRET=MindestenS32ZeichenLangesGeheimnis_UNBEDINGT_AENDERN!
JWT_EXPIRATION_MS=86400000

# ── Frontend ───────────────────────────────────────────────
# In Prod: echte Domain oder leer lassen (nginx-Proxy greift)
VITE_API_BASE_URL=http://localhost:8080/api/v1
```

---

## .gitignore  (Ergänzungen)
```gitignore
# Secrets – NIEMALS ins Repository!
.env
*.env.local
*.env.production

# Docker-Volumes
pgdata/
uploads/

# Build-Artefakte
backend/target/
frontend/dist/
frontend/node_modules/
```

---

## Nützliche Befehle

### Alles starten (Produktion)
```bash
# 1. .env anlegen
cp .env.example .env
# → .env anpassen (Passwörter, JWT-Secret)

# 2. Backend bauen
cd backend && mvn package -DskipTests && cd ..

# 3. Alle Container starten
docker compose up -d --build

# 4. Logs beobachten
docker compose logs -f
```

### Entwicklungsmodus (Hot-Reload)
```bash
docker compose -f docker-compose.yml -f docker-compose.dev.yml up
```

### Tests ausführen
```bash
docker compose -f docker-compose.test.yml up --abort-on-container-exit
```

### Datenbankzugriff
```bash
docker exec -it caems-postgres psql -U caems -d caems
```

### Einzelnen Service neu bauen
```bash
docker compose up -d --build backend
```

### Alles stoppen und aufräumen
```bash
docker compose down -v   # -v löscht auch Volumes (Vorsicht: DB-Daten weg!)
```

### Container-Status & Ressourcen
```bash
docker compose ps
docker stats caems-backend caems-postgres caems-frontend
```

---

## Ports-Übersicht

| Service   | Host-Port | Container-Port | Beschreibung            |
|-----------|-----------|----------------|-------------------------|
| frontend  | 3000      | 80             | React App (nginx)       |
| backend   | 8080      | 8080           | Spring Boot REST API    |
| postgres  | 5432      | 5432           | PostgreSQL (dev only)   |
| backend   | 5005      | 5005           | Java Remote Debug (dev) |
| frontend  | 5173      | 5173           | Vite Dev-Server (dev)   |

---

## Healthcheck-Ablauf beim Start

```
postgres     → healthy  (pg_isready)
  ↓
backend      → healthy  (actuator/health)
  ↓
frontend     → läuft    (nginx)
```

Spring Boot wartet automatisch auf die DB (depends_on + condition: service_healthy).
Der Frontend-Container wartet auf das Backend, bevor er sich bereit meldet.
