# CAEMS – Backend vollständig (Spring Boot 4.x)

## Verzeichnisstruktur
```
backend/src/main/java/com/caems/
├── CaemsApplication.java
├── config/
│   ├── SecurityConfig.java
│   ├── JwtConfig.java
│   └── SwaggerConfig.java
├── model/
│   ├── Employee.java
│   ├── Hardware.java
│   ├── Software.java
│   ├── SoftwareAssignment.java
│   └── Loan.java
├── dto/
│   ├── EmployeeDTO.java
│   ├── HardwareDTO.java
│   ├── SoftwareDTO.java
│   ├── LoanDTO.java
│   ├── LoginRequest.java
│   └── JwtResponse.java
├── repository/
│   ├── EmployeeRepository.java
│   ├── HardwareRepository.java
│   ├── SoftwareRepository.java
│   └── LoanRepository.java
├── service/
│   ├── EmployeeService.java
│   ├── HardwareService.java
│   ├── SoftwareService.java
│   ├── LoanService.java
│   └── JwtService.java
├── controller/
│   ├── AuthController.java
│   ├── EmployeeController.java
│   ├── HardwareController.java
│   ├── SoftwareController.java
│   └── LoanController.java
├── exception/
│   ├── GlobalExceptionHandler.java
│   ├── ResourceNotFoundException.java
│   └── BusinessException.java
└── mapper/
    ├── EmployeeMapper.java
    ├── HardwareMapper.java
    └── LoanMapper.java
```

---

## pom.xml
```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
         https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>4.0.0</version>
    </parent>

    <groupId>com.caems</groupId>
    <artifactId>caems-backend</artifactId>
    <version>1.0.0</version>
    <name>CAEMS Backend</name>

    <properties>
        <java.version>21</java.version>
        <mapstruct.version>1.5.5.Final</mapstruct.version>
        <jjwt.version>0.12.6</jjwt.version>
        <testcontainers.version>1.19.8</testcontainers.version>
    </properties>

    <dependencies>
        <!-- Web -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>

        <!-- JPA + Postgres -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>
        <dependency>
            <groupId>org.postgresql</groupId>
            <artifactId>postgresql</artifactId>
            <scope>runtime</scope>
        </dependency>

        <!-- Security -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-security</artifactId>
        </dependency>

        <!-- JWT -->
        <dependency>
            <groupId>io.jsonwebtoken</groupId>
            <artifactId>jjwt-api</artifactId>
            <version>${jjwt.version}</version>
        </dependency>
        <dependency>
            <groupId>io.jsonwebtoken</groupId>
            <artifactId>jjwt-impl</artifactId>
            <version>${jjwt.version}</version>
            <scope>runtime</scope>
        </dependency>
        <dependency>
            <groupId>io.jsonwebtoken</groupId>
            <artifactId>jjwt-jackson</artifactId>
            <version>${jjwt.version}</version>
            <scope>runtime</scope>
        </dependency>

        <!-- Validation -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-validation</artifactId>
        </dependency>

        <!-- Flyway DB-Migrationen -->
        <dependency>
            <groupId>org.flywaydb</groupId>
            <artifactId>flyway-core</artifactId>
        </dependency>
        <dependency>
            <groupId>org.flywaydb</groupId>
            <artifactId>flyway-database-postgresql</artifactId>
        </dependency>

        <!-- Swagger / OpenAPI -->
        <dependency>
            <groupId>org.springdoc</groupId>
            <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
            <version>2.5.0</version>
        </dependency>

        <!-- MapStruct -->
        <dependency>
            <groupId>org.mapstruct</groupId>
            <artifactId>mapstruct</artifactId>
            <version>${mapstruct.version}</version>
        </dependency>

        <!-- Lombok -->
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>

        <!-- Datei-Upload -->
        <dependency>
            <groupId>commons-io</groupId>
            <artifactId>commons-io</artifactId>
            <version>2.16.1</version>
        </dependency>

        <!-- Test -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.springframework.security</groupId>
            <artifactId>spring-security-test</artifactId>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.testcontainers</groupId>
            <artifactId>junit-jupiter</artifactId>
            <version>${testcontainers.version}</version>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.testcontainers</groupId>
            <artifactId>postgresql</artifactId>
            <version>${testcontainers.version}</version>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <configuration>
                    <annotationProcessorPaths>
                        <path>
                            <groupId>org.mapstruct</groupId>
                            <artifactId>mapstruct-processor</artifactId>
                            <version>${mapstruct.version}</version>
                        </path>
                        <path>
                            <groupId>org.projectlombok</groupId>
                            <artifactId>lombok</artifactId>
                        </path>
                    </annotationProcessorPaths>
                </configuration>
            </plugin>
        </plugins>
    </build>
</project>
```

---

## application.yml
```yaml
spring:
  datasource:
    url: jdbc:postgresql://localhost:5432/caems
    username: caems
    password: caems_secret
    driver-class-name: org.postgresql.Driver
    hikari:
      maximum-pool-size: 10
      connection-timeout: 20000

  jpa:
    hibernate:
      ddl-auto: validate
    show-sql: false
    properties:
      hibernate:
        dialect: org.hibernate.dialect.PostgreSQLDialect
        format_sql: true
        default_schema: public

  flyway:
    enabled: true
    locations: classpath:db/migration
    baseline-on-migrate: true

  servlet:
    multipart:
      enabled: true
      max-file-size: 10MB
      max-request-size: 10MB

springdoc:
  api-docs:
    path: /api-docs
  swagger-ui:
    path: /swagger-ui.html
    operationsSorter: method

app:
  jwt:
    secret: ${JWT_SECRET:MindestenS32ZeichenLangerGeheimSchluessel!}
    expiration-ms: 86400000   # 24 Stunden
  upload:
    dir: ${UPLOAD_DIR:./uploads/photos}
  cors:
    allowed-origins: http://localhost:3000,http://localhost:5173

logging:
  level:
    com.caems: DEBUG
    org.springframework.security: INFO
```

---

## Flyway Migrationen

### V1__create_employees.sql
```sql
CREATE TABLE employees (
    id              BIGSERIAL PRIMARY KEY,
    employee_number VARCHAR(20)  UNIQUE NOT NULL,
    first_name      VARCHAR(100) NOT NULL,
    last_name       VARCHAR(100) NOT NULL,
    email           VARCHAR(255) UNIQUE NOT NULL,
    phone           VARCHAR(50),
    position        VARCHAR(100),
    department      VARCHAR(100),
    hire_date       DATE         NOT NULL,
    salary          DECIMAL(12,2),
    photo_url       VARCHAR(500),
    street          VARCHAR(200),
    city            VARCHAR(100),
    zip_code        VARCHAR(20),
    country         VARCHAR(100) DEFAULT 'Deutschland',
    active          BOOLEAN      DEFAULT TRUE,
    created_at      TIMESTAMP    DEFAULT NOW(),
    updated_at      TIMESTAMP    DEFAULT NOW()
);

CREATE INDEX idx_employees_department ON employees(department);
CREATE INDEX idx_employees_active     ON employees(active);
```

### V2__create_hardware.sql
```sql
CREATE TYPE hardware_status AS ENUM (
    'AVAILABLE', 'LOANED', 'MAINTENANCE', 'RETIRED'
);

CREATE TABLE hardware (
    id              BIGSERIAL PRIMARY KEY,
    asset_tag       VARCHAR(50)  UNIQUE NOT NULL,
    name            VARCHAR(200) NOT NULL,
    category        VARCHAR(100),
    manufacturer    VARCHAR(100),
    model           VARCHAR(100),
    serial_number   VARCHAR(100) UNIQUE,
    purchase_date   DATE,
    purchase_price  DECIMAL(10,2),
    warranty_until  DATE,
    status          hardware_status DEFAULT 'AVAILABLE',
    notes           TEXT,
    created_at      TIMESTAMP DEFAULT NOW(),
    updated_at      TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_hardware_status   ON hardware(status);
CREATE INDEX idx_hardware_category ON hardware(category);
```

### V3__create_software_and_loans.sql
```sql
CREATE TABLE software (
    id               BIGSERIAL PRIMARY KEY,
    name             VARCHAR(200) NOT NULL,
    vendor           VARCHAR(100),
    version          VARCHAR(50),
    category         VARCHAR(100),
    license_type     VARCHAR(50),
    total_licenses   INT     DEFAULT 1,
    used_licenses    INT     DEFAULT 0,
    cost_per_license DECIMAL(10,2),
    renewal_date     DATE,
    notes            TEXT,
    created_at       TIMESTAMP DEFAULT NOW()
);

CREATE TABLE loans (
    id          BIGSERIAL PRIMARY KEY,
    employee_id BIGINT REFERENCES employees(id) ON DELETE RESTRICT,
    hardware_id BIGINT REFERENCES hardware(id)  ON DELETE RESTRICT,
    loan_date   DATE      NOT NULL DEFAULT CURRENT_DATE,
    return_date DATE,
    returned_at TIMESTAMP,
    notes       TEXT,
    created_at  TIMESTAMP DEFAULT NOW(),
    CONSTRAINT uq_active_loan UNIQUE (hardware_id, returned_at)
);

CREATE TABLE software_assignments (
    id            BIGSERIAL PRIMARY KEY,
    employee_id   BIGINT REFERENCES employees(id) ON DELETE CASCADE,
    software_id   BIGINT REFERENCES software(id)  ON DELETE CASCADE,
    assigned_date DATE NOT NULL DEFAULT CURRENT_DATE,
    revoked_date  DATE,
    license_key   VARCHAR(255),
    CONSTRAINT uq_active_assignment
        UNIQUE (employee_id, software_id, revoked_date)
);

CREATE INDEX idx_loans_employee   ON loans(employee_id);
CREATE INDEX idx_loans_hardware   ON loans(hardware_id);
CREATE INDEX idx_loans_returned   ON loans(returned_at);
```

### V4__insert_test_data.sql
```sql
INSERT INTO employees (employee_number, first_name, last_name, email, position, department, hire_date, salary)
VALUES
  ('EMP-001', 'Maximilian', 'Bauer',   'm.bauer@firma.de',   'Senior Developer', 'Engineering', '2021-03-15', 85000),
  ('EMP-002', 'Sophie',     'Müller',  's.mueller@firma.de', 'Product Manager',  'Product',     '2020-07-01', 90000),
  ('EMP-003', 'Jonas',      'Weber',   'j.weber@firma.de',   'UX Designer',      'Design',      '2022-01-10', 72000);

INSERT INTO hardware (asset_tag, name, category, manufacturer, model, serial_number, status, purchase_date, warranty_until)
VALUES
  ('HW-0001', 'MacBook Pro 16"', 'LAPTOP',    'Apple',  'MK183D/A', 'C02XY12345', 'AVAILABLE', '2022-06-01', '2025-06-01'),
  ('HW-0002', 'Dell UltraSharp', 'MONITOR',   'Dell',   'U2722D',   'D3L7890',    'AVAILABLE', '2022-06-15', '2025-06-15'),
  ('HW-0003', 'ThinkPad X1',     'LAPTOP',    'Lenovo', 'Gen 10',   'LNV4567',    'AVAILABLE', '2021-11-10', '2024-11-10');

INSERT INTO software (name, vendor, version, category, license_type, total_licenses, cost_per_license, renewal_date)
VALUES
  ('Microsoft 365',    'Microsoft', '2024',   'PRODUCTIVITY', 'SUBSCRIPTION', 50, 12.50, '2025-01-01'),
  ('IntelliJ IDEA',    'JetBrains', '2024.1', 'DEV_TOOLS',    'SUBSCRIPTION', 15, 24.90, '2025-06-30'),
  ('Figma Business',   'Figma',     'Web',    'DESIGN',       'SUBSCRIPTION', 10, 45.00, '2025-09-01');
```

---

## Models

### Employee.java
```java
package com.caems.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "employees")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "employee_number", unique = true, nullable = false, length = 20)
    @NotBlank(message = "Mitarbeiternummer ist pflicht")
    private String employeeNumber;

    @Column(name = "first_name", nullable = false, length = 100)
    @NotBlank(message = "Vorname ist pflicht")
    private String firstName;

    @Column(name = "last_name", nullable = false, length = 100)
    @NotBlank(message = "Nachname ist pflicht")
    private String lastName;

    @Column(unique = true, nullable = false, length = 255)
    @Email(message = "Ungültige E-Mail-Adresse")
    @NotBlank
    private String email;

    @Column(length = 50)
    private String phone;

    @Column(length = 100)
    private String position;

    @Column(length = 100)
    private String department;

    @Column(name = "hire_date", nullable = false)
    @NotNull(message = "Einstellungsdatum ist pflicht")
    private LocalDate hireDate;

    @Column(precision = 12, scale = 2)
    @DecimalMin(value = "0.0", message = "Gehalt darf nicht negativ sein")
    private BigDecimal salary;

    @Column(name = "photo_url", length = 500)
    private String photoUrl;

    @Column(length = 200)
    private String street;

    @Column(length = 100)
    private String city;

    @Column(name = "zip_code", length = 20)
    private String zipCode;

    @Column(length = 100)
    @Builder.Default
    private String country = "Deutschland";

    @Builder.Default
    private boolean active = true;

    @OneToMany(mappedBy = "employee", fetch = FetchType.LAZY)
    @Builder.Default
    private List<Loan> loans = new ArrayList<>();

    @OneToMany(mappedBy = "employee", fetch = FetchType.LAZY)
    @Builder.Default
    private List<SoftwareAssignment> softwareAssignments = new ArrayList<>();

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
```

### Hardware.java
```java
package com.caems.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "hardware")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Hardware {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "asset_tag", unique = true, nullable = false, length = 50)
    @NotBlank
    private String assetTag;

    @Column(nullable = false, length = 200)
    @NotBlank
    private String name;

    @Column(length = 100)
    private String category;

    @Column(length = 100)
    private String manufacturer;

    @Column(length = 100)
    private String model;

    @Column(name = "serial_number", unique = true, length = 100)
    private String serialNumber;

    @Column(name = "purchase_date")
    private LocalDate purchaseDate;

    @Column(name = "purchase_price", precision = 10, scale = 2)
    private BigDecimal purchasePrice;

    @Column(name = "warranty_until")
    private LocalDate warrantyUntil;

    @Column(columnDefinition = "hardware_status")
    @Enumerated(EnumType.STRING)
    @Builder.Default
    private HardwareStatus status = HardwareStatus.AVAILABLE;

    @Column(columnDefinition = "TEXT")
    private String notes;

    @OneToMany(mappedBy = "hardware", fetch = FetchType.LAZY)
    @Builder.Default
    private List<Loan> loans = new ArrayList<>();

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public enum HardwareStatus {
        AVAILABLE, LOANED, MAINTENANCE, RETIRED
    }
}
```

### Loan.java
```java
package com.caems.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "loans")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Loan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "hardware_id", nullable = false)
    private Hardware hardware;

    @Column(name = "loan_date", nullable = false)
    @Builder.Default
    private LocalDate loanDate = LocalDate.now();

    @Column(name = "return_date")
    private LocalDate returnDate;

    @Column(name = "returned_at")
    private LocalDateTime returnedAt;

    @Column(columnDefinition = "TEXT")
    private String notes;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    public boolean isActive() {
        return returnedAt == null;
    }
}
```

### SoftwareAssignment.java
```java
package com.caems.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "software_assignments")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SoftwareAssignment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "software_id", nullable = false)
    private Software software;

    @Column(name = "assigned_date")
    @Builder.Default
    private LocalDate assignedDate = LocalDate.now();

    @Column(name = "revoked_date")
    private LocalDate revokedDate;

    @Column(name = "license_key", length = 255)
    private String licenseKey;

    public boolean isActive() {
        return revokedDate == null;
    }
}
```

---

## Repositories

### EmployeeRepository.java
```java
package com.caems.repository;

import com.caems.model.Employee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    Optional<Employee> findByEmail(String email);

    boolean existsByEmail(String email);
    boolean existsByEmployeeNumber(String employeeNumber);

    @Query("""
        SELECT e FROM Employee e
        WHERE e.active = true
          AND (:search IS NULL OR
               LOWER(e.firstName) LIKE LOWER(CONCAT('%', :search, '%')) OR
               LOWER(e.lastName)  LIKE LOWER(CONCAT('%', :search, '%')) OR
               LOWER(e.email)     LIKE LOWER(CONCAT('%', :search, '%')) OR
               LOWER(e.department) LIKE LOWER(CONCAT('%', :search, '%')) OR
               LOWER(e.position)   LIKE LOWER(CONCAT('%', :search, '%')) OR
               e.employeeNumber    LIKE CONCAT('%', :search, '%'))
        """)
    Page<Employee> searchActive(@Param("search") String search, Pageable pageable);

    Page<Employee> findAllByDepartment(String department, Pageable pageable);
}
```

### HardwareRepository.java
```java
package com.caems.repository;

import com.caems.model.Hardware;
import com.caems.model.Hardware.HardwareStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface HardwareRepository extends JpaRepository<Hardware, Long> {

    Optional<Hardware> findByAssetTag(String assetTag);
    boolean existsByAssetTag(String assetTag);
    boolean existsBySerialNumber(String serialNumber);

    List<Hardware> findByStatus(HardwareStatus status);

    @Query("""
        SELECT h FROM Hardware h
        WHERE (:search IS NULL OR
               LOWER(h.name)         LIKE LOWER(CONCAT('%', :search, '%')) OR
               LOWER(h.manufacturer) LIKE LOWER(CONCAT('%', :search, '%')) OR
               LOWER(h.assetTag)     LIKE LOWER(CONCAT('%', :search, '%')))
          AND (:status IS NULL OR h.status = :status)
        """)
    Page<Hardware> search(@Param("search") String search,
                          @Param("status") HardwareStatus status,
                          Pageable pageable);

    @Query("SELECT h FROM Hardware h WHERE h.warrantyUntil < :date AND h.status != 'RETIRED'")
    List<Hardware> findWarrantyExpiredBefore(@Param("date") LocalDate date);
}
```

### LoanRepository.java
```java
package com.caems.repository;

import com.caems.model.Loan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface LoanRepository extends JpaRepository<Loan, Long> {

    @Query("SELECT l FROM Loan l WHERE l.hardware.id = :hwId AND l.returnedAt IS NULL")
    Optional<Loan> findActiveLoanByHardwareId(@Param("hwId") Long hardwareId);

    @Query("SELECT l FROM Loan l WHERE l.employee.id = :empId AND l.returnedAt IS NULL")
    List<Loan> findActiveByEmployeeId(@Param("empId") Long employeeId);

    @Query("SELECT l FROM Loan l WHERE l.employee.id = :empId ORDER BY l.loanDate DESC")
    List<Loan> findAllByEmployeeId(@Param("empId") Long employeeId);
}
```

---

## Services

### EmployeeService.java
```java
package com.caems.service;

import com.caems.dto.EmployeeDTO;
import com.caems.exception.BusinessException;
import com.caems.exception.ResourceNotFoundException;
import com.caems.mapper.EmployeeMapper;
import com.caems.model.Employee;
import com.caems.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class EmployeeService {

    private final EmployeeRepository repo;
    private final EmployeeMapper mapper;

    @Transactional(readOnly = true)
    public Page<EmployeeDTO> findAll(Pageable pageable, String search) {
        return repo.searchActive(search, pageable).map(mapper::toDTO);
    }

    @Transactional(readOnly = true)
    public EmployeeDTO findById(Long id) {
        return repo.findById(id)
                .map(mapper::toDTO)
                .orElseThrow(() -> new ResourceNotFoundException("Mitarbeiter", id));
    }

    public EmployeeDTO create(EmployeeDTO dto, MultipartFile photo) {
        if (repo.existsByEmail(dto.getEmail()))
            throw new BusinessException("E-Mail bereits vorhanden: " + dto.getEmail());
        if (repo.existsByEmployeeNumber(dto.getEmployeeNumber()))
            throw new BusinessException("Mitarbeiternummer bereits vorhanden: " + dto.getEmployeeNumber());

        Employee entity = mapper.toEntity(dto);

        if (photo != null && !photo.isEmpty()) {
            String photoUrl = savePhoto(photo, dto.getEmployeeNumber());
            entity.setPhotoUrl(photoUrl);
        }

        Employee saved = repo.save(entity);
        log.info("Mitarbeiter angelegt: {} ({})", saved.getEmail(), saved.getEmployeeNumber());
        return mapper.toDTO(saved);
    }

    public EmployeeDTO update(Long id, EmployeeDTO dto) {
        Employee existing = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Mitarbeiter", id));

        // E-Mail-Änderung auf Duplikat prüfen
        if (!existing.getEmail().equals(dto.getEmail()) && repo.existsByEmail(dto.getEmail()))
            throw new BusinessException("E-Mail bereits vorhanden: " + dto.getEmail());

        mapper.updateEntity(dto, existing);
        return mapper.toDTO(repo.save(existing));
    }

    public void deactivate(Long id) {
        Employee emp = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Mitarbeiter", id));
        emp.setActive(false);
        repo.save(emp);
        log.info("Mitarbeiter deaktiviert: {}", id);
    }

    private String savePhoto(MultipartFile file, String employeeNumber) {
        try {
            String ext = FilenameUtils.getExtension(file.getOriginalFilename());
            String filename = employeeNumber + "_" + UUID.randomUUID() + "." + ext;
            Path uploadDir = Paths.get("./uploads/photos");
            Files.createDirectories(uploadDir);
            Path target = uploadDir.resolve(filename);
            Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
            return "/uploads/photos/" + filename;
        } catch (IOException e) {
            throw new BusinessException("Foto-Upload fehlgeschlagen: " + e.getMessage());
        }
    }
}
```

### LoanService.java
```java
package com.caems.service;

import com.caems.dto.LoanDTO;
import com.caems.exception.BusinessException;
import com.caems.exception.ResourceNotFoundException;
import com.caems.mapper.LoanMapper;
import com.caems.model.Employee;
import com.caems.model.Hardware;
import com.caems.model.Loan;
import com.caems.repository.EmployeeRepository;
import com.caems.repository.HardwareRepository;
import com.caems.repository.LoanRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class LoanService {

    private final LoanRepository loanRepo;
    private final EmployeeRepository employeeRepo;
    private final HardwareRepository hardwareRepo;
    private final LoanMapper loanMapper;

    public LoanDTO loanHardware(Long employeeId, Long hardwareId, LocalDate returnDate, String notes) {
        Employee employee = employeeRepo.findById(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException("Mitarbeiter", employeeId));

        Hardware hardware = hardwareRepo.findById(hardwareId)
                .orElseThrow(() -> new ResourceNotFoundException("Hardware", hardwareId));

        // Prüfen ob Hardware verfügbar ist
        if (hardware.getStatus() != Hardware.HardwareStatus.AVAILABLE)
            throw new BusinessException("Hardware ist nicht verfügbar. Status: " + hardware.getStatus());

        // Aktive Ausleihe prüfen (Doppelschutz)
        loanRepo.findActiveLoanByHardwareId(hardwareId).ifPresent(l -> {
            throw new BusinessException("Hardware ist bereits ausgeliehen");
        });

        Loan loan = Loan.builder()
                .employee(employee)
                .hardware(hardware)
                .loanDate(LocalDate.now())
                .returnDate(returnDate)
                .notes(notes)
                .build();

        hardware.setStatus(Hardware.HardwareStatus.LOANED);
        hardwareRepo.save(hardware);

        Loan saved = loanRepo.save(loan);
        log.info("Hardware ausgeliehen: {} → {}", hardware.getAssetTag(), employee.getEmail());
        return loanMapper.toDTO(saved);
    }

    public LoanDTO returnHardware(Long hardwareId, String notes) {
        Loan loan = loanRepo.findActiveLoanByHardwareId(hardwareId)
                .orElseThrow(() -> new BusinessException("Keine aktive Ausleihe für Hardware: " + hardwareId));

        loan.setReturnedAt(LocalDateTime.now());
        if (notes != null) loan.setNotes(notes);

        Hardware hardware = loan.getHardware();
        hardware.setStatus(Hardware.HardwareStatus.AVAILABLE);
        hardwareRepo.save(hardware);

        Loan saved = loanRepo.save(loan);
        log.info("Hardware zurückgegeben: {}", hardware.getAssetTag());
        return loanMapper.toDTO(saved);
    }

    @Transactional(readOnly = true)
    public List<LoanDTO> getActiveLoansForEmployee(Long employeeId) {
        return loanRepo.findActiveByEmployeeId(employeeId)
                .stream().map(loanMapper::toDTO).toList();
    }

    @Transactional(readOnly = true)
    public List<LoanDTO> getLoanHistoryForEmployee(Long employeeId) {
        return loanRepo.findAllByEmployeeId(employeeId)
                .stream().map(loanMapper::toDTO).toList();
    }
}
```

### SoftwareService.java
```java
package com.caems.service;

import com.caems.exception.BusinessException;
import com.caems.exception.ResourceNotFoundException;
import com.caems.model.*;
import com.caems.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class SoftwareService {

    private final SoftwareRepository softwareRepo;
    private final EmployeeRepository employeeRepo;
    private final SoftwareAssignmentRepository assignmentRepo;

    public void assignLicense(Long softwareId, Long employeeId, String licenseKey) {
        Software sw = softwareRepo.findById(softwareId)
                .orElseThrow(() -> new ResourceNotFoundException("Software", softwareId));

        Employee emp = employeeRepo.findById(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException("Mitarbeiter", employeeId));

        // Duplikat-Check
        boolean alreadyAssigned = assignmentRepo.existsActiveAssignment(employeeId, softwareId);
        if (alreadyAssigned)
            throw new BusinessException("Lizenz bereits zugewiesen");

        // Kapazitätsprüfung
        if (sw.getUsedLicenses() >= sw.getTotalLicenses())
            throw new BusinessException("Keine freien Lizenzen verfügbar für: " + sw.getName());

        SoftwareAssignment assignment = SoftwareAssignment.builder()
                .employee(emp)
                .software(sw)
                .licenseKey(licenseKey)
                .build();

        assignmentRepo.save(assignment);
        sw.setUsedLicenses(sw.getUsedLicenses() + 1);
        softwareRepo.save(sw);
    }

    public void revokeLicense(Long softwareId, Long employeeId) {
        SoftwareAssignment assignment = assignmentRepo
                .findActiveAssignment(employeeId, softwareId)
                .orElseThrow(() -> new BusinessException("Keine aktive Lizenzzuweisung gefunden"));

        assignment.setRevokedDate(java.time.LocalDate.now());
        assignmentRepo.save(assignment);

        Software sw = assignment.getSoftware();
        sw.setUsedLicenses(Math.max(0, sw.getUsedLicenses() - 1));
        softwareRepo.save(sw);
    }
}
```

---

## Controllers

### LoanController.java
```java
package com.caems.controller;

import com.caems.dto.LoanDTO;
import com.caems.dto.LoanRequestDTO;
import com.caems.service.LoanService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/loans")
@RequiredArgsConstructor
@Tag(name = "Ausleihe", description = "Hardware-Ausleihe und Rückgabe")
public class LoanController {

    private final LoanService loanService;

    @PostMapping("/hardware/{hardwareId}/loan")
    @Operation(summary = "Hardware ausleihen")
    public ResponseEntity<LoanDTO> loanHardware(
            @PathVariable Long hardwareId,
            @Valid @RequestBody LoanRequestDTO request) {
        return ResponseEntity.ok(
                loanService.loanHardware(
                        request.getEmployeeId(), hardwareId,
                        request.getReturnDate(), request.getNotes()));
    }

    @PostMapping("/hardware/{hardwareId}/return")
    @Operation(summary = "Hardware zurückgeben")
    public ResponseEntity<LoanDTO> returnHardware(
            @PathVariable Long hardwareId,
            @RequestParam(required = false) String notes) {
        return ResponseEntity.ok(loanService.returnHardware(hardwareId, notes));
    }

    @GetMapping("/employees/{employeeId}/active")
    @Operation(summary = "Aktive Ausleihen eines Mitarbeiters")
    public ResponseEntity<List<LoanDTO>> getActiveLoans(@PathVariable Long employeeId) {
        return ResponseEntity.ok(loanService.getActiveLoansForEmployee(employeeId));
    }

    @GetMapping("/employees/{employeeId}/history")
    @Operation(summary = "Ausleihhistorie eines Mitarbeiters")
    public ResponseEntity<List<LoanDTO>> getLoanHistory(@PathVariable Long employeeId) {
        return ResponseEntity.ok(loanService.getLoanHistoryForEmployee(employeeId));
    }
}
```

### AuthController.java
```java
package com.caems.controller;

import com.caems.dto.JwtResponse;
import com.caems.dto.LoginRequest;
import com.caems.service.JwtService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
@Tag(name = "Auth", description = "Login und Token")
public class AuthController {

    private final AuthenticationManager authManager;
    private final JwtService jwtService;

    @PostMapping("/login")
    public ResponseEntity<JwtResponse> login(@Valid @RequestBody LoginRequest request) {
        Authentication auth = authManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));

        String token = jwtService.generateToken(auth.getName());
        return ResponseEntity.ok(new JwtResponse(token, jwtService.getExpirationMs()));
    }
}
```

---

## Security & JWT

### SecurityConfig.java
```java
package com.caems.config;

import com.caems.service.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

@Configuration
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtService jwtService;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http
            .csrf(c -> c.disable())
            .cors(c -> c.configurationSource(corsConfig()))
            .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/v1/auth/**").permitAll()
                .requestMatchers("/swagger-ui/**", "/api-docs/**").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/v1/**").hasAnyRole("ADMIN", "HR", "IT", "VIEWER")
                .requestMatchers(HttpMethod.POST, "/api/v1/employees/**").hasAnyRole("ADMIN", "HR")
                .requestMatchers(HttpMethod.PUT,  "/api/v1/employees/**").hasAnyRole("ADMIN", "HR")
                .requestMatchers("/api/v1/loans/**").hasAnyRole("ADMIN", "IT")
                .anyRequest().hasRole("ADMIN")
            )
            .addFilterBefore(jwtAuthFilter(), UsernamePasswordAuthenticationFilter.class)
            .build();
    }

    @Bean
    public JwtAuthFilter jwtAuthFilter() {
        return new JwtAuthFilter(jwtService);
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public CorsConfigurationSource corsConfig() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(List.of("http://localhost:3000", "http://localhost:5173"));
        config.setAllowedMethods(List.of("GET","POST","PUT","DELETE","OPTIONS"));
        config.setAllowedHeaders(List.of("*"));
        config.setAllowCredentials(true);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/api/**", config);
        return source;
    }
}
```

### JwtService.java
```java
package com.caems.service;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

@Service
public class JwtService {

    @Value("${app.jwt.secret}")
    private String secret;

    @Value("${app.jwt.expiration-ms}")
    private long expirationMs;

    private SecretKey key() {
        return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    public String generateToken(String subject) {
        return Jwts.builder()
                .subject(subject)
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + expirationMs))
                .signWith(key())
                .compact();
    }

    public String extractSubject(String token) {
        return Jwts.parser().verifyWith(key()).build()
                .parseSignedClaims(token).getPayload().getSubject();
    }

    public boolean isTokenValid(String token) {
        try {
            Jwts.parser().verifyWith(key()).build().parseSignedClaims(token);
            return true;
        } catch (JwtException e) {
            return false;
        }
    }

    public long getExpirationMs() { return expirationMs; }
}
```

### JwtAuthFilter.java
```java
package com.caems.config;

import com.caems.service.JwtService;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@RequiredArgsConstructor
public class JwtAuthFilter extends OncePerRequestFilter {

    private final JwtService jwtService;
    private final UserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(HttpServletRequest req,
                                    HttpServletResponse res,
                                    FilterChain chain) throws ServletException, IOException {
        String authHeader = req.getHeader("Authorization");

        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);
            if (jwtService.isTokenValid(token)) {
                String email = jwtService.extractSubject(token);
                UserDetails user = userDetailsService.loadUserByUsername(email);
                var auth = new UsernamePasswordAuthenticationToken(
                        user, null, user.getAuthorities());
                SecurityContextHolder.getContext().setAuthentication(auth);
            }
        }
        chain.doFilter(req, res);
    }
}
```

---

## Exception Handling

### GlobalExceptionHandler.java
```java
package com.caems.exception;

import org.springframework.http.*;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.*;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleNotFound(ResourceNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(new ErrorResponse(404, ex.getMessage(), LocalDateTime.now()));
    }

    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<ErrorResponse> handleBusiness(BusinessException ex) {
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(new ErrorResponse(409, ex.getMessage(), LocalDateTime.now()));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidation(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new LinkedHashMap<>();
        for (FieldError fe : ex.getBindingResult().getFieldErrors()) {
            errors.put(fe.getField(), fe.getDefaultMessage());
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errors);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGeneric(Exception ex) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ErrorResponse(500, "Interner Serverfehler", LocalDateTime.now()));
    }

    public record ErrorResponse(int status, String message, LocalDateTime timestamp) {}
}
```

---

## Tests

### EmployeeServiceTest.java (Unit)
```java
@ExtendWith(MockitoExtension.class)
class EmployeeServiceTest {

    @Mock EmployeeRepository repo;
    @Mock EmployeeMapper mapper;
    @InjectMocks EmployeeService service;

    @Test
    @DisplayName("findById – Erfolg")
    void findById_success() {
        Employee emp = Employee.builder().id(1L).email("test@firma.de").build();
        EmployeeDTO dto = new EmployeeDTO(); dto.setId(1L);

        when(repo.findById(1L)).thenReturn(Optional.of(emp));
        when(mapper.toDTO(emp)).thenReturn(dto);

        EmployeeDTO result = service.findById(1L);

        assertThat(result.getId()).isEqualTo(1L);
        verify(repo).findById(1L);
    }

    @Test
    @DisplayName("findById – 404")
    void findById_notFound() {
        when(repo.findById(99L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.findById(99L));
    }

    @Test
    @DisplayName("create – Duplikat E-Mail wirft Exception")
    void create_duplicateEmail() {
        EmployeeDTO dto = new EmployeeDTO();
        dto.setEmail("exists@firma.de");
        when(repo.existsByEmail("exists@firma.de")).thenReturn(true);
        assertThrows(BusinessException.class, () -> service.create(dto, null));
    }
}
```

### LoanServiceTest.java (Unit)
```java
@ExtendWith(MockitoExtension.class)
class LoanServiceTest {

    @Mock LoanRepository loanRepo;
    @Mock EmployeeRepository employeeRepo;
    @Mock HardwareRepository hardwareRepo;
    @Mock LoanMapper loanMapper;
    @InjectMocks LoanService service;

    @Test
    @DisplayName("loanHardware – Erfolg")
    void loanHardware_success() {
        Employee emp = Employee.builder().id(1L).build();
        Hardware hw = Hardware.builder().id(2L)
                .status(Hardware.HardwareStatus.AVAILABLE).build();
        Loan loan = Loan.builder().id(10L).employee(emp).hardware(hw).build();
        LoanDTO dto = new LoanDTO(); dto.setId(10L);

        when(employeeRepo.findById(1L)).thenReturn(Optional.of(emp));
        when(hardwareRepo.findById(2L)).thenReturn(Optional.of(hw));
        when(loanRepo.findActiveLoanByHardwareId(2L)).thenReturn(Optional.empty());
        when(loanRepo.save(any())).thenReturn(loan);
        when(loanMapper.toDTO(loan)).thenReturn(dto);

        LoanDTO result = service.loanHardware(1L, 2L, null, null);
        assertThat(result.getId()).isEqualTo(10L);
        assertThat(hw.getStatus()).isEqualTo(Hardware.HardwareStatus.LOANED);
    }

    @Test
    @DisplayName("loanHardware – Hardware nicht verfügbar")
    void loanHardware_notAvailable() {
        Employee emp = Employee.builder().id(1L).build();
        Hardware hw = Hardware.builder().id(2L)
                .status(Hardware.HardwareStatus.LOANED).build();

        when(employeeRepo.findById(1L)).thenReturn(Optional.of(emp));
        when(hardwareRepo.findById(2L)).thenReturn(Optional.of(hw));

        assertThrows(BusinessException.class,
                () -> service.loanHardware(1L, 2L, null, null));
    }
}
```

### EmployeeControllerIT.java (Integration / Testcontainers)
```java
@SpringBootTest(webEnvironment = RANDOM_PORT)
@AutoConfigureMockMvc
@Testcontainers
class EmployeeControllerIT {

    @Container
    static PostgreSQLContainer<?> postgres =
        new PostgreSQLContainer<>("postgres:16")
            .withDatabaseName("caems_test")
            .withUsername("test")
            .withPassword("test");

    @DynamicPropertySource
    static void props(DynamicPropertyRegistry r) {
        r.add("spring.datasource.url",      postgres::getJdbcUrl);
        r.add("spring.datasource.username", postgres::getUsername);
        r.add("spring.datasource.password", postgres::getPassword);
        r.add("spring.flyway.enabled",      () -> "true");
    }

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;
    @Autowired EmployeeRepository repo;

    @BeforeEach void clean() { repo.deleteAll(); }

    @Test
    @WithMockUser(roles = "ADMIN")
    void createEmployee_201() throws Exception {
        String body = """
            {
              "employeeNumber": "EMP-TEST-001",
              "firstName": "Hans",
              "lastName": "Test",
              "email": "hans@test.de",
              "hireDate": "2024-01-01",
              "position": "Tester",
              "department": "QA"
            }
            """;

        mockMvc.perform(post("/api/v1/employees")
                .contentType(APPLICATION_JSON).content(body))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.email").value("hans@test.de"))
            .andExpect(jsonPath("$.employeeNumber").value("EMP-TEST-001"));
    }

    @Test
    @WithMockUser(roles = "VIEWER")
    void getEmployee_notFound_404() throws Exception {
        mockMvc.perform(get("/api/v1/employees/999"))
            .andExpect(status().isNotFound());
    }

    @Test
    @WithMockUser(roles = "HR")
    void createEmployee_duplicateEmail_409() throws Exception {
        // Ersten Mitarbeiter anlegen
        Employee emp = Employee.builder()
            .employeeNumber("EMP-001").firstName("A").lastName("B")
            .email("dup@test.de").hireDate(LocalDate.now()).build();
        repo.save(emp);

        // Gleiche E-Mail erneut → 409
        String body = """
            {"employeeNumber":"EMP-002","firstName":"C","lastName":"D",
             "email":"dup@test.de","hireDate":"2024-01-01"}
            """;
        mockMvc.perform(post("/api/v1/employees")
                .contentType(APPLICATION_JSON).content(body))
            .andExpect(status().isConflict());
    }
}
```
