# CAEMS – E2E-Tests mit Playwright

---

## Inhaltsverzeichnis

1. [Setup & Installation](#1-setup--installation)
2. [Playwright Konfiguration](#2-playwright-konfiguration)
3. [Page Object Model](#3-page-object-model)
4. [Auth-Tests](#4-auth-tests)
5. [Mitarbeiter-Tests](#5-mitarbeiter-tests)
6. [Hardware & Ausleihe-Tests](#6-hardware--ausleihe-tests)
7. [Software & Lizenz-Tests](#7-software--lizenz-tests)
8. [Fixtures & Testdaten](#8-fixtures--testdaten)
9. [CI/CD Integration](#9-cicd-integration)
10. [Nützliche Befehle](#10-nützliche-befehle)

---

## 1. Setup & Installation

### package.json – Abhängigkeiten

```json
{
  "devDependencies": {
    "@playwright/test": "^1.44.0",
    "@types/node": "^20.0.0"
  },
  "scripts": {
    "e2e":          "playwright test",
    "e2e:ui":       "playwright test --ui",
    "e2e:headed":   "playwright test --headed",
    "e2e:debug":    "playwright test --debug",
    "e2e:report":   "playwright show-report"
  }
}
```

### Installation

```bash
cd frontend
npm install --save-dev @playwright/test
npx playwright install --with-deps chromium firefox webkit
```

### Verzeichnisstruktur

```
frontend/
└── e2e/
    ├── playwright.config.ts
    ├── fixtures/
    │   ├── auth.fixture.ts
    │   └── data.fixture.ts
    ├── pages/
    │   ├── LoginPage.ts
    │   ├── DashboardPage.ts
    │   ├── EmployeesPage.ts
    │   ├── HardwarePage.ts
    │   └── SoftwarePage.ts
    └── tests/
        ├── auth.spec.ts
        ├── employees.spec.ts
        ├── hardware.spec.ts
        └── software.spec.ts
```

---

## 2. Playwright Konfiguration

Datei: `e2e/playwright.config.ts`

```typescript
import { defineConfig, devices } from "@playwright/test";

export default defineConfig({
  testDir: "./e2e/tests",
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 2 : undefined,
  timeout: 30_000,
  expect: { timeout: 5_000 },

  reporter: [
    ["html", { outputFolder: "e2e/report", open: "never" }],
    ["junit", { outputFile: "e2e/results.xml" }],
    ["list"],
  ],

  use: {
    baseURL:       process.env.BASE_URL ?? "http://localhost:3000",
    trace:         "on-first-retry",
    screenshot:    "only-on-failure",
    video:         "retain-on-failure",
    actionTimeout: 10_000,
  },

  projects: [
    // Setup: Login-State speichern
    {
      name: "setup",
      testMatch: "**/auth.setup.ts",
    },

    // Chromium mit gespeichertem Auth-State
    {
      name: "chromium",
      use: {
        ...devices["Desktop Chrome"],
        storageState: "e2e/.auth/user.json",
      },
      dependencies: ["setup"],
    },

    // Firefox
    {
      name: "firefox",
      use: {
        ...devices["Desktop Firefox"],
        storageState: "e2e/.auth/user.json",
      },
      dependencies: ["setup"],
    },

    // Mobile
    {
      name: "mobile-chrome",
      use: {
        ...devices["Pixel 7"],
        storageState: "e2e/.auth/user.json",
      },
      dependencies: ["setup"],
    },
  ],

  // Lokalen Dev-Server starten falls nicht läuft
  webServer: {
    command: "npm run dev",
    url:     "http://localhost:3000",
    reuseExistingServer: !process.env.CI,
    timeout: 120_000,
  },
});
```

### Auth Setup

Datei: `e2e/tests/auth.setup.ts`

```typescript
import { test as setup, expect } from "@playwright/test";
import path from "path";

const authFile = path.join(__dirname, "../.auth/user.json");

setup("Login-State speichern", async ({ page }) => {
  await page.goto("/");
  await page.getByLabel("E-Mail").fill("admin@firma.de");
  await page.getByLabel("Passwort").fill("admin123");
  await page.getByRole("button", { name: "Anmelden" }).click();

  // Warten bis Dashboard geladen
  await expect(page.getByText("Dashboard")).toBeVisible();

  // Auth-State für alle Tests speichern
  await page.context().storageState({ path: authFile });
});
```

---

## 3. Page Object Model

### LoginPage.ts

```typescript
import { Page, Locator, expect } from "@playwright/test";

export class LoginPage {
  readonly page:          Page;
  readonly emailInput:    Locator;
  readonly passwordInput: Locator;
  readonly loginButton:   Locator;
  readonly errorMessage:  Locator;

  constructor(page: Page) {
    this.page          = page;
    this.emailInput    = page.getByLabel("E-Mail");
    this.passwordInput = page.getByLabel("Passwort");
    this.loginButton   = page.getByRole("button", { name: "Anmelden" });
    this.errorMessage  = page.getByRole("alert");
  }

  async goto() {
    await this.page.goto("/login");
  }

  async login(email: string, password: string) {
    await this.emailInput.fill(email);
    await this.passwordInput.fill(password);
    await this.loginButton.click();
  }

  async expectLoginError(message: string) {
    await expect(this.errorMessage).toContainText(message);
  }

  async expectRedirectToDashboard() {
    await expect(this.page).toHaveURL(/.*dashboard/);
    await expect(this.page.getByText("Dashboard")).toBeVisible();
  }
}
```

### EmployeesPage.ts

```typescript
import { Page, Locator, expect } from "@playwright/test";

export class EmployeesPage {
  readonly page:          Page;
  readonly searchInput:   Locator;
  readonly addButton:     Locator;
  readonly employeeList:  Locator;
  readonly detailPanel:   Locator;

  constructor(page: Page) {
    this.page         = page;
    this.searchInput  = page.getByPlaceholder(/Name.*suchen/);
    this.addButton    = page.getByRole("button", { name: /Mitarbeiter/ });
    this.employeeList = page.getByTestId("employee-list");
    this.detailPanel  = page.getByTestId("employee-detail");
  }

  async goto() {
    await this.page.getByRole("button", { name: "Mitarbeiter" }).click();
    await expect(this.employeeList).toBeVisible();
  }

  async search(query: string) {
    await this.searchInput.fill(query);
    await this.page.waitForTimeout(300); // Debounce
  }

  async selectEmployee(name: string) {
    await this.employeeList
      .getByText(name)
      .first()
      .click();
    await expect(this.detailPanel).toBeVisible();
  }

  async openAddForm() {
    await this.addButton.click();
    await expect(this.page.getByRole("dialog")).toBeVisible();
  }

  async fillEmployeeForm(data: {
    employeeNumber: string;
    firstName:      string;
    lastName:       string;
    email:          string;
    hireDate:       string;
    position?:      string;
    department?:    string;
    salary?:        string;
  }) {
    const dialog = this.page.getByRole("dialog");
    await dialog.getByLabel("Mitarbeiter-Nr.").fill(data.employeeNumber);
    await dialog.getByLabel("Vorname").fill(data.firstName);
    await dialog.getByLabel("Nachname").fill(data.lastName);
    await dialog.getByLabel("E-Mail").fill(data.email);
    await dialog.getByLabel("Einstellungsdatum").fill(data.hireDate);
    if (data.position)   await dialog.getByLabel("Position").fill(data.position);
    if (data.department) await dialog.getByLabel("Abteilung").selectOption(data.department);
    if (data.salary)     await dialog.getByLabel(/Gehalt/).fill(data.salary);
  }

  async saveForm() {
    await this.page.getByRole("button", { name: "Speichern" }).click();
  }

  async expectEmployeeInList(name: string) {
    await expect(this.employeeList.getByText(name)).toBeVisible();
  }

  async expectEmployeeDetail(data: Partial<{
    name:       string;
    position:   string;
    department: string;
    email:      string;
  }>) {
    if (data.name)       await expect(this.detailPanel.getByText(data.name)).toBeVisible();
    if (data.position)   await expect(this.detailPanel.getByText(data.position)).toBeVisible();
    if (data.department) await expect(this.detailPanel.getByText(data.department)).toBeVisible();
    if (data.email)      await expect(this.detailPanel.getByText(data.email)).toBeVisible();
  }
}
```

### HardwarePage.ts

```typescript
import { Page, Locator, expect } from "@playwright/test";

export class HardwarePage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async goto() {
    await this.page.getByRole("button", { name: "Hardware" }).click();
  }

  async filterByStatus(status: "AVAILABLE" | "LOANED" | "MAINTENANCE" | "RETIRED") {
    const labels: Record<string, string> = {
      AVAILABLE:   "Verfügbar",
      LOANED:      "Ausgeliehen",
      MAINTENANCE: "Wartung",
      RETIRED:     "Ausgemustert",
    };
    await this.page.getByRole("button", { name: labels[status] }).click();
  }

  async openLoanDialog(assetTag: string) {
    const row = this.page.getByText(assetTag).locator("..").locator("..");
    await row.getByRole("button", { name: /Ausleihen/ }).click();
    await expect(this.page.getByRole("dialog")).toBeVisible();
  }

  async loanHardware(assetTag: string, employeeName: string, returnDate?: string) {
    await this.openLoanDialog(assetTag);
    const dialog = this.page.getByRole("dialog");
    await dialog.getByLabel("Mitarbeiter").selectOption({ label: employeeName });
    if (returnDate) {
      await dialog.getByLabel("Rückgabedatum").fill(returnDate);
    }
    await dialog.getByRole("button", { name: /Ausleihen/ }).click();
  }

  async returnHardware(assetTag: string, notes?: string) {
    const row = this.page.getByText(assetTag).locator("..").locator("..");
    await row.getByRole("button", { name: /Rückgabe/ }).click();
    const dialog = this.page.getByRole("dialog");
    if (notes) await dialog.getByLabel("Zustandsnotiz").fill(notes);
    await dialog.getByRole("button", { name: /Zurückgeben/ }).click();
  }

  async expectHardwareStatus(assetTag: string, status: string) {
    const row = this.page.getByText(assetTag).locator("..").locator("..");
    await expect(row.getByText(status)).toBeVisible();
  }

  async expectToast(message: string) {
    await expect(this.page.getByText(message)).toBeVisible({ timeout: 5000 });
  }
}
```

---

## 4. Auth-Tests

Datei: `e2e/tests/auth.spec.ts`

```typescript
import { test, expect } from "@playwright/test";
import { LoginPage } from "../pages/LoginPage";

// Auth-Tests laufen OHNE gespeicherten State
test.use({ storageState: { cookies: [], origins: [] } });

test.describe("Authentifizierung", () => {

  test("Login mit gültigen Zugangsdaten", async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();

    await loginPage.login("admin@firma.de", "admin123");
    await loginPage.expectRedirectToDashboard();

    // JWT im localStorage gespeichert
    const token = await page.evaluate(() => localStorage.getItem("jwt"));
    expect(token).toBeTruthy();
  });

  test("Login mit falschem Passwort zeigt Fehler", async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();

    await loginPage.login("admin@firma.de", "falsch");
    await loginPage.expectLoginError("Ungültige Zugangsdaten");
  });

  test("Login mit leerer E-Mail zeigt Validierungsfehler", async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();

    await loginPage.login("", "admin123");
    // HTML5-Validierung
    const emailInput = page.getByLabel("E-Mail");
    await expect(emailInput).toBeFocused();
  });

  test("Abmelden löscht Session", async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login("admin@firma.de", "admin123");
    await loginPage.expectRedirectToDashboard();

    // Abmelden
    await page.getByRole("button", { name: "Abmelden" }).click();

    // Zurück zum Login
    await expect(page).toHaveURL(/.*login/);
    const token = await page.evaluate(() => localStorage.getItem("jwt"));
    expect(token).toBeNull();
  });

  test("Geschützte Seite leitet zu Login weiter", async ({ page }) => {
    await page.goto("/employees");
    await expect(page).toHaveURL(/.*login/);
  });
});
```

---

## 5. Mitarbeiter-Tests

Datei: `e2e/tests/employees.spec.ts`

```typescript
import { test, expect } from "@playwright/test";
import { EmployeesPage } from "../pages/EmployeesPage";

test.describe("Mitarbeiterverwaltung", () => {

  test("Mitarbeiterliste wird angezeigt", async ({ page }) => {
    const empPage = new EmployeesPage(page);
    await page.goto("/");
    await empPage.goto();

    await expect(page.getByTestId("employee-list")).toBeVisible();
    // Mindestens ein Mitarbeiter vorhanden
    const items = page.getByTestId("employee-list-item");
    await expect(items).toHaveCount(await items.count(), { timeout: 5000 });
    expect(await items.count()).toBeGreaterThan(0);
  });

  test("Mitarbeiter suchen filtert die Liste", async ({ page }) => {
    const empPage = new EmployeesPage(page);
    await page.goto("/");
    await empPage.goto();

    await empPage.search("Bauer");

    const items = page.getByTestId("employee-list-item");
    await expect(items).toHaveCount(1);
    await expect(items.first()).toContainText("Bauer");
  });

  test("Suche ohne Treffer zeigt leere Liste", async ({ page }) => {
    const empPage = new EmployeesPage(page);
    await page.goto("/");
    await empPage.goto();

    await empPage.search("XxNichtVorhandenXx");
    await expect(page.getByText("Keine Mitarbeiter gefunden")).toBeVisible();
  });

  test("Mitarbeiter auswählen zeigt Detail-Panel", async ({ page }) => {
    const empPage = new EmployeesPage(page);
    await page.goto("/");
    await empPage.goto();

    await empPage.selectEmployee("Maximilian Bauer");

    await empPage.expectEmployeeDetail({
      name:       "Maximilian Bauer",
      position:   "Senior Developer",
      department: "Engineering",
    });
  });

  test("Neuer Mitarbeiter anlegen", async ({ page }) => {
    const empPage = new EmployeesPage(page);
    await page.goto("/");
    await empPage.goto();

    await empPage.openAddForm();
    await empPage.fillEmployeeForm({
      employeeNumber: "EMP-E2E-001",
      firstName:      "Test",
      lastName:       "Playwright",
      email:          `pw.test.${Date.now()}@firma.de`,
      hireDate:       "2024-06-01",
      position:       "QA Engineer",
      department:     "Engineering",
      salary:         "65000",
    });
    await empPage.saveForm();

    // Erfolgs-Toast erscheint
    await expect(page.getByText(/gespeichert/)).toBeVisible();
    // Mitarbeiter in Liste
    await empPage.expectEmployeeInList("Test Playwright");
  });

  test("Pflichtfeld-Validierung beim Anlegen", async ({ page }) => {
    const empPage = new EmployeesPage(page);
    await page.goto("/");
    await empPage.goto();

    await empPage.openAddForm();
    // Formular leer absenden
    await empPage.saveForm();

    // Fehler erscheinen
    await expect(page.getByText("Pflichtfeld").first()).toBeVisible();
  });

  test("Master-Detail Layout – beide Bereiche sichtbar", async ({ page }) => {
    const empPage = new EmployeesPage(page);
    await page.goto("/");
    await empPage.goto();

    await expect(page.getByTestId("employee-list")).toBeVisible();
    await expect(page.getByTestId("employee-detail")).toBeVisible();
  });

  test("Grid-Ansicht umschalten", async ({ page }) => {
    const empPage = new EmployeesPage(page);
    await page.goto("/");
    await empPage.goto();

    await page.getByTitle("Grid-Ansicht").click();
    await expect(page.getByTestId("employee-grid")).toBeVisible();

    // Zurück zu Liste
    await page.getByTitle("Listen-Ansicht").click();
    await expect(page.getByTestId("employee-list")).toBeVisible();
  });
});
```

---

## 6. Hardware & Ausleihe-Tests

Datei: `e2e/tests/hardware.spec.ts`

```typescript
import { test, expect } from "@playwright/test";
import { HardwarePage } from "../pages/HardwarePage";

test.describe("Hardware-Verwaltung", () => {

  test("Hardware-Liste wird angezeigt", async ({ page }) => {
    const hwPage = new HardwarePage(page);
    await page.goto("/");
    await hwPage.goto();

    await expect(page.getByTestId("hardware-table")).toBeVisible();
    const rows = page.getByTestId("hardware-row");
    expect(await rows.count()).toBeGreaterThan(0);
  });

  test("Filter 'Verfügbar' zeigt nur verfügbare Hardware", async ({ page }) => {
    const hwPage = new HardwarePage(page);
    await page.goto("/");
    await hwPage.goto();

    await hwPage.filterByStatus("AVAILABLE");

    const badges = page.getByText("Verfügbar");
    const rows   = page.getByTestId("hardware-row");
    // Jede Zeile zeigt "Verfügbar"
    await expect(badges).toHaveCount(await rows.count());
  });

  test("Verfügbare Hardware ausleihen", async ({ page }) => {
    const hwPage = new HardwarePage(page);
    await page.goto("/");
    await hwPage.goto();

    // Verfügbare Hardware filtern
    await hwPage.filterByStatus("AVAILABLE");

    // Erste verfügbare Hardware ausleihen
    await hwPage.loanHardware("HW-0001", "Maximilian Bauer");

    // Status hat sich geändert
    await hwPage.expectHardwareStatus("HW-0001", "Ausgeliehen");
    await hwPage.expectToast("ausgeliehen");
  });

  test("Ausgeliehene Hardware zurückgeben", async ({ page }) => {
    const hwPage = new HardwarePage(page);
    await page.goto("/");
    await hwPage.goto();

    await hwPage.filterByStatus("LOANED");
    await hwPage.returnHardware("HW-0002", "Gerät in einwandfreiem Zustand");

    await hwPage.expectHardwareStatus("HW-0002", "Verfügbar");
    await hwPage.expectToast("zurückgenommen");
  });

  test("Bereits ausgeliehene Hardware kann nicht erneut ausgeliehen werden", async ({ page }) => {
    const hwPage = new HardwarePage(page);
    await page.goto("/");
    await hwPage.goto();

    await hwPage.filterByStatus("LOANED");

    // Der "Ausleihen"-Button sollte bei LOANED-Hardware nicht sichtbar sein
    const row = page.getByText("HW-0002").locator("..").locator("..");
    await expect(row.getByRole("button", { name: /Ausleihen/ })).not.toBeVisible();
    await expect(row.getByRole("button", { name: /Rückgabe/ })).toBeVisible();
  });

  test("Garantie-Warnung bei abgelaufener Garantie", async ({ page }) => {
    const hwPage = new HardwarePage(page);
    await page.goto("/");
    await hwPage.goto();

    // Abgelaufene Garantie zeigt Warnsymbol
    await expect(page.getByText("⚠️").first()).toBeVisible();
  });

  test("Hardware-Suche filtert Tabelle", async ({ page }) => {
    const hwPage = new HardwarePage(page);
    await page.goto("/");
    await hwPage.goto();

    await page.getByPlaceholder(/Hardware suchen/).fill("MacBook");

    const rows = page.getByTestId("hardware-row");
    for (let i = 0; i < await rows.count(); i++) {
      await expect(rows.nth(i)).toContainText("MacBook");
    }
  });
});
```

---

## 7. Software & Lizenz-Tests

Datei: `e2e/tests/software.spec.ts`

```typescript
import { test, expect } from "@playwright/test";

test.describe("Software & Lizenzen", () => {

  test("Software-Liste wird angezeigt", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("button", { name: /Software/ }).click();

    const cards = page.getByTestId("software-card");
    expect(await cards.count()).toBeGreaterThan(0);
  });

  test("Lizenzauslastung wird als Fortschrittsbalken angezeigt", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("button", { name: /Software/ }).click();

    await expect(page.getByTestId("license-progress").first()).toBeVisible();
  });

  test("Warnung bei hoher Lizenzauslastung (≥85%)", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("button", { name: /Software/ }).click();

    // Warnsymbol bei kritischer Auslastung
    await expect(page.getByText("⚠️").first()).toBeVisible();
  });

  test("Lizenz einem Mitarbeiter zuweisen", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("button", { name: /Software/ }).click();

    // Ersten Zuweisen-Button klicken
    await page.getByRole("button", { name: "Zuweisen" }).first().click();

    const dialog = page.getByRole("dialog");
    await expect(dialog).toBeVisible();

    await dialog.getByLabel("Mitarbeiter").selectOption({ index: 1 });
    await dialog.getByRole("button", { name: "Zuweisen" }).click();

    await expect(page.getByText("zugewiesen")).toBeVisible();
  });

  test("Ablaufdatum nahe zeigt Warnung an", async ({ page }) => {
    await page.goto("/");
    await page.getByRole("button", { name: /Software/ }).click();

    // Ablaufwarnungen vorhanden
    await expect(page.getByTestId("renewal-warning").first()).toBeVisible();
  });
});
```

---

## 8. Fixtures & Testdaten

Datei: `e2e/fixtures/data.fixture.ts`

```typescript
import { test as base } from "@playwright/test";

// Testdaten-Typen
export type Employee = {
  employeeNumber: string;
  firstName:      string;
  lastName:       string;
  email:          string;
  hireDate:       string;
  position:       string;
  department:     string;
};

// Fixture mit API-Calls zum Backend
export const test = base.extend<{
  testEmployee: Employee;
  cleanupEmployees: void;
}>({
  // Mitarbeiter vor dem Test anlegen, nach dem Test löschen
  testEmployee: async ({ request }, use) => {
    const employee: Employee = {
      employeeNumber: `EMP-TEST-${Date.now()}`,
      firstName:      "Playwright",
      lastName:       "Test",
      email:          `pw.${Date.now()}@test.de`,
      hireDate:       "2024-01-01",
      position:       "Tester",
      department:     "Engineering",
    };

    // Via API anlegen
    const response = await request.post("/api/v1/employees", {
      data: employee,
      headers: { Authorization: `Bearer ${process.env.TEST_JWT}` },
    });
    const created = await response.json();

    // Test ausführen
    await use({ ...employee, ...created });

    // Aufräumen
    await request.delete(`/api/v1/employees/${created.id}`, {
      headers: { Authorization: `Bearer ${process.env.TEST_JWT}` },
    });
  },
});

export { expect } from "@playwright/test";
```

---

## 9. CI/CD Integration

Ergänzung in `.github/workflows/ci-cd.yml`:

```yaml
  # ── E2E-Tests ─────────────────────────────────────────────
  e2e-tests:
    name: 🎭 E2E Tests (Playwright)
    runs-on: ubuntu-latest
    needs: [backend-test, frontend-test]
    timeout-minutes: 30

    services:
      postgres:
        image: postgres:16-alpine
        env:
          POSTGRES_DB:       caems_e2e
          POSTGRES_USER:     e2e
          POSTGRES_PASSWORD: e2e
        ports:
          - 5432:5432
        options: >-
          --health-cmd "pg_isready -U e2e"
          --health-interval 10s
          --health-retries 5

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Java einrichten
        uses: actions/setup-java@v4
        with:
          java-version: "21"
          distribution: temurin
          cache: maven

      - name: Node.js einrichten
        uses: actions/setup-node@v4
        with:
          node-version: "20"
          cache: npm
          cache-dependency-path: frontend/package-lock.json

      - name: Backend bauen & starten
        working-directory: backend
        env:
          SPRING_DATASOURCE_URL:      jdbc:postgresql://localhost:5432/caems_e2e
          SPRING_DATASOURCE_USERNAME: e2e
          SPRING_DATASOURCE_PASSWORD: e2e
        run: |
          mvn package -DskipTests -B
          java -jar target/caems-backend-1.0.0.jar &
          echo "⏳ Warte auf Backend..."
          timeout 60 bash -c 'until curl -sf http://localhost:8080/actuator/health; do sleep 2; done'
          echo "✅ Backend läuft"

      - name: Frontend-Abhängigkeiten installieren
        working-directory: frontend
        run: npm ci

      - name: Playwright-Browser installieren
        working-directory: frontend
        run: npx playwright install --with-deps chromium

      - name: E2E-Tests ausführen
        working-directory: frontend
        env:
          BASE_URL:  http://localhost:3000
          TEST_JWT:  ${{ secrets.E2E_JWT_TOKEN }}
        run: npm run e2e

      - name: Playwright Report hochladen
        uses: actions/upload-artifact@v4
        if: always()
        with:
          name: playwright-report
          path: frontend/e2e/report/
          retention-days: 14

      - name: JUnit-Ergebnisse veröffentlichen
        uses: dorny/test-reporter@v1
        if: always()
        with:
          name: Playwright E2E Tests
          path: frontend/e2e/results.xml
          reporter: java-junit
```

---

## 10. Nützliche Befehle

```bash
# Alle Tests ausführen
npm run e2e

# Mit UI-Modus (interaktiv)
npm run e2e:ui

# Einzelne Spec-Datei
npx playwright test e2e/tests/employees.spec.ts

# Nur bestimmte Tests (nach Name)
npx playwright test --grep "ausleihen"

# Mit sichtbarem Browser
npm run e2e:headed

# Debug-Modus (Step-by-Step)
npm run e2e:debug

# Report anzeigen
npm run e2e:report

# Nur Chromium
npx playwright test --project=chromium

# Screenshots bei Fehlern ansehen
ls e2e/report/
```
