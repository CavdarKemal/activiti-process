# CAEMS – Monitoring & Logging
## Prometheus · Grafana · Loki · Alertmanager

---

## Inhaltsverzeichnis

1. [Architektur-Übersicht](#1-architektur-übersicht)
2. [Docker Compose – Monitoring-Stack](#2-docker-compose--monitoring-stack)
3. [Spring Boot – Actuator & Metriken](#3-spring-boot--actuator--metriken)
4. [Prometheus Konfiguration](#4-prometheus-konfiguration)
5. [Grafana Dashboards](#5-grafana-dashboards)
6. [Loki – Log-Aggregation](#6-loki--log-aggregation)
7. [Alertmanager – Benachrichtigungen](#7-alertmanager--benachrichtigungen)
8. [Alert-Regeln](#8-alert-regeln)
9. [GitHub Actions – Monitoring-Integration](#9-github-actions--monitoring-integration)
10. [Ports & URLs Übersicht](#10-ports--urls-übersicht)

---

## 1. Architektur-Übersicht

```
┌─────────────────────────────────────────────────────────────┐
│                        CAEMS Stack                          │
│                                                             │
│  ┌──────────┐   Metriken   ┌────────────┐                  │
│  │ Backend  │──────────────► Prometheus │                  │
│  │ :8080    │  /actuator/  │  :9090     │                  │
│  │          │   prometheus │            │                  │
│  └──────────┘              └─────┬──────┘                  │
│                                  │ scrape                   │
│  ┌──────────┐   Logs       ┌─────▼──────┐  Alerts          │
│  │ Backend  │──────────────► Loki       ├──────────────────►│
│  │ (Logback)│  promtail    │  :3100     │  Alertmanager     │
│  └──────────┘              └─────┬──────┘  :9093            │
│                                  │                          │
│  ┌──────────┐              ┌─────▼──────┐                  │
│  │ Postgres │──────────────► Grafana    │  → Slack / E-Mail │
│  │ Exporter │              │  :3001     │                  │
│  └──────────┘              └────────────┘                  │
└─────────────────────────────────────────────────────────────┘
```

**Komponenten:**

| Tool | Aufgabe | Port |
|------|---------|------|
| **Prometheus** | Metriken sammeln & speichern | 9090 |
| **Grafana** | Dashboards & Visualisierung | 3001 |
| **Loki** | Log-Aggregation | 3100 |
| **Promtail** | Log-Shipper (Docker → Loki) | 9080 |
| **Alertmanager** | Alert-Routing (Slack, E-Mail) | 9093 |
| **postgres-exporter** | PostgreSQL-Metriken | 9187 |
| **node-exporter** | Server-Metriken (CPU, RAM, Disk) | 9100 |

---

## 2. Docker Compose – Monitoring-Stack

Datei: `docker-compose.monitoring.yml`

```yaml
version: "3.9"

services:

  # ── Prometheus ──────────────────────────────────────────
  prometheus:
    image: prom/prometheus:v2.51.0
    container_name: caems-prometheus
    restart: unless-stopped
    command:
      - --config.file=/etc/prometheus/prometheus.yml
      - --storage.tsdb.path=/prometheus
      - --storage.tsdb.retention.time=30d
      - --web.enable-lifecycle
      - --web.enable-admin-api
    volumes:
      - ./monitoring/prometheus/prometheus.yml:/etc/prometheus/prometheus.yml:ro
      - ./monitoring/prometheus/rules:/etc/prometheus/rules:ro
      - prometheus-data:/prometheus
    ports:
      - "9090:9090"
    networks:
      - caems-net
      - monitoring-net
    healthcheck:
      test: ["CMD", "wget", "-qO-", "http://localhost:9090/-/healthy"]
      interval: 15s
      timeout: 5s
      retries: 3

  # ── Grafana ─────────────────────────────────────────────
  grafana:
    image: grafana/grafana:10.4.0
    container_name: caems-grafana
    restart: unless-stopped
    environment:
      GF_SECURITY_ADMIN_USER:     ${GRAFANA_USER:-admin}
      GF_SECURITY_ADMIN_PASSWORD: ${GRAFANA_PASSWORD:-admin123}
      GF_USERS_ALLOW_SIGN_UP:     "false"
      GF_SERVER_ROOT_URL:         http://localhost:3001
      GF_INSTALL_PLUGINS:         grafana-clock-panel,grafana-piechart-panel
    volumes:
      - grafana-data:/var/lib/grafana
      - ./monitoring/grafana/provisioning:/etc/grafana/provisioning:ro
      - ./monitoring/grafana/dashboards:/var/lib/grafana/dashboards:ro
    ports:
      - "3001:3000"
    networks:
      - monitoring-net
    depends_on:
      - prometheus
      - loki
    healthcheck:
      test: ["CMD", "wget", "-qO-", "http://localhost:3000/api/health"]
      interval: 15s
      timeout: 5s
      retries: 3

  # ── Loki ────────────────────────────────────────────────
  loki:
    image: grafana/loki:2.9.7
    container_name: caems-loki
    restart: unless-stopped
    command: -config.file=/etc/loki/config.yml
    volumes:
      - ./monitoring/loki/config.yml:/etc/loki/config.yml:ro
      - loki-data:/loki
    ports:
      - "3100:3100"
    networks:
      - monitoring-net
    healthcheck:
      test: ["CMD", "wget", "-qO-", "http://localhost:3100/ready"]
      interval: 15s
      timeout: 5s
      retries: 5

  # ── Promtail (Log-Shipper) ──────────────────────────────
  promtail:
    image: grafana/promtail:2.9.7
    container_name: caems-promtail
    restart: unless-stopped
    command: -config.file=/etc/promtail/config.yml
    volumes:
      - ./monitoring/promtail/config.yml:/etc/promtail/config.yml:ro
      - /var/lib/docker/containers:/var/lib/docker/containers:ro
      - /var/run/docker.sock:/var/run/docker.sock:ro
    networks:
      - monitoring-net
    depends_on:
      - loki

  # ── Alertmanager ────────────────────────────────────────
  alertmanager:
    image: prom/alertmanager:v0.27.0
    container_name: caems-alertmanager
    restart: unless-stopped
    command:
      - --config.file=/etc/alertmanager/config.yml
      - --storage.path=/alertmanager
    volumes:
      - ./monitoring/alertmanager/config.yml:/etc/alertmanager/config.yml:ro
      - alertmanager-data:/alertmanager
    ports:
      - "9093:9093"
    networks:
      - monitoring-net

  # ── PostgreSQL Exporter ─────────────────────────────────
  postgres-exporter:
    image: prometheuscommunity/postgres-exporter:v0.15.0
    container_name: caems-postgres-exporter
    restart: unless-stopped
    environment:
      DATA_SOURCE_NAME: postgresql://${POSTGRES_USER:-caems}:${POSTGRES_PASSWORD:-caems_secret}@postgres:5432/${POSTGRES_DB:-caems}?sslmode=disable
    ports:
      - "9187:9187"
    networks:
      - caems-net
      - monitoring-net
    depends_on:
      - prometheus

  # ── Node Exporter (Server-Metriken) ─────────────────────
  node-exporter:
    image: prom/node-exporter:v1.7.0
    container_name: caems-node-exporter
    restart: unless-stopped
    command:
      - --path.rootfs=/host
      - --collector.filesystem.mount-points-exclude=^/(sys|proc|dev|host|etc)($$|/)
    volumes:
      - /:/host:ro,rslave
    ports:
      - "9100:9100"
    networks:
      - monitoring-net
    pid: host

volumes:
  prometheus-data:  { name: caems-prometheus-data }
  grafana-data:     { name: caems-grafana-data }
  loki-data:        { name: caems-loki-data }
  alertmanager-data:{ name: caems-alertmanager-data }

networks:
  caems-net:
    external: true
    name: caems-network
  monitoring-net:
    name: caems-monitoring
    driver: bridge
```

**Starten:**
```bash
docker compose -f docker-compose.yml -f docker-compose.monitoring.yml up -d
```

---

## 3. Spring Boot – Actuator & Metriken

### pom.xml – Abhängigkeiten hinzufügen

```xml
<!-- Spring Boot Actuator -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-actuator</artifactId>
</dependency>

<!-- Micrometer → Prometheus -->
<dependency>
    <groupId>io.micrometer</groupId>
    <artifactId>micrometer-registry-prometheus</artifactId>
</dependency>

<!-- Loki Log-Appender -->
<dependency>
    <groupId>com.github.loki4j</groupId>
    <artifactId>loki-logback-appender</artifactId>
    <version>1.5.1</version>
</dependency>
```

### application.yml – Actuator konfigurieren

```yaml
management:
  endpoints:
    web:
      exposure:
        include: health, info, prometheus, metrics, loggers
      base-path: /actuator
  endpoint:
    health:
      show-details: when-authorized
      probes:
        enabled: true   # /actuator/health/liveness + readiness
    prometheus:
      enabled: true
  metrics:
    tags:
      application: caems-backend
      environment: ${SPRING_PROFILES_ACTIVE:local}
    distribution:
      percentiles-histogram:
        http.server.requests: true
      percentiles:
        http.server.requests: 0.5, 0.9, 0.95, 0.99
  prometheus:
    metrics:
      export:
        enabled: true
```

### Eigene Business-Metriken – MetricsService.java

```java
package com.caems.service;

import io.micrometer.core.instrument.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicInteger;

@Component
@RequiredArgsConstructor
public class MetricsService {

    private final MeterRegistry registry;

    // Zähler: wie oft wurde Hardware ausgeliehen
    public void recordLoan() {
        registry.counter("caems.loans.total",
                "action", "loan").increment();
    }

    // Zähler: Rückgaben
    public void recordReturn() {
        registry.counter("caems.loans.total",
                "action", "return").increment();
    }

    // Gauge: aktive Ausleihen (Echtzeit)
    public void trackActiveLoans(AtomicInteger activeLoans) {
        Gauge.builder("caems.loans.active", activeLoans, AtomicInteger::get)
             .description("Anzahl aktiver Hardware-Ausleihen")
             .register(registry);
    }

    // Gauge: Lizenzauslastung pro Software
    public void trackLicenseUsage(String softwareName, int used, int total) {
        Gauge.builder("caems.licenses.usage_percent",
                     () -> total > 0 ? (double) used / total * 100 : 0)
             .tag("software", softwareName)
             .description("Lizenzauslastung in Prozent")
             .register(registry);
    }

    // Timer: Dauer von DB-Operationen messen
    public <T> T timeDbOperation(String operation, java.util.function.Supplier<T> fn) {
        return Timer.builder("caems.db.operation.duration")
                .tag("operation", operation)
                .description("Dauer von Datenbankoperationen")
                .register(registry)
                .record(fn);
    }
}
```

### Logback-Konfiguration – logback-spring.xml

Datei: `backend/src/main/resources/logback-spring.xml`

```xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>

    <!-- Konsolen-Output -->
    <appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender">
        <encoder class="net.logstash.logback.encoder.LogstashEncoder">
            <includeMdcKeyName>traceId</includeMdcKeyName>
            <includeMdcKeyName>spanId</includeMdcKeyName>
        </encoder>
    </appender>

    <!-- Loki-Appender -->
    <appender name="LOKI" class="com.github.loki4j.logback.Loki4jAppender">
        <http>
            <url>http://loki:3100/loki/api/v1/push</url>
        </http>
        <format>
            <label>
                <pattern>
                    app=caems-backend,
                    level=%level,
                    host=${HOSTNAME},
                    env=${SPRING_PROFILES_ACTIVE:-local}
                </pattern>
            </label>
            <message>
                <pattern>
                    level=%level
                    logger=%logger{36}
                    thread=%thread
                    msg=%message
                    %ex{full}
                </pattern>
            </message>
        </format>
        <batchMaxItems>100</batchMaxItems>
        <batchTimeoutMs>5000</batchTimeoutMs>
    </appender>

    <!-- Root Logger -->
    <root level="INFO">
        <appender-ref ref="CONSOLE"/>
        <appender-ref ref="LOKI"/>
    </root>

    <logger name="com.caems" level="DEBUG"/>
    <logger name="org.springframework.security" level="INFO"/>
    <logger name="org.hibernate.SQL" level="DEBUG"/>

</configuration>
```

---

## 4. Prometheus Konfiguration

Datei: `monitoring/prometheus/prometheus.yml`

```yaml
global:
  scrape_interval:     15s
  evaluation_interval: 15s
  external_labels:
    cluster: caems-prod
    env:     production

alerting:
  alertmanagers:
    - static_configs:
        - targets: [alertmanager:9093]

rule_files:
  - /etc/prometheus/rules/*.yml

scrape_configs:

  # ── Spring Boot Backend ──────────────────────────────────
  - job_name: caems-backend
    metrics_path: /actuator/prometheus
    static_configs:
      - targets: [backend:8080]
    relabel_configs:
      - source_labels: [__address__]
        target_label: instance
        replacement: caems-backend

  # ── PostgreSQL ───────────────────────────────────────────
  - job_name: postgres
    static_configs:
      - targets: [postgres-exporter:9187]

  # ── Server (Node Exporter) ───────────────────────────────
  - job_name: node
    static_configs:
      - targets: [node-exporter:9100]

  # ── Prometheus selbst ────────────────────────────────────
  - job_name: prometheus
    static_configs:
      - targets: [localhost:9090]
```

---

## 5. Grafana Dashboards

### Provisioning – Datasources

Datei: `monitoring/grafana/provisioning/datasources/datasources.yml`

```yaml
apiVersion: 1

datasources:

  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
    jsonData:
      timeInterval: 15s

  - name: Loki
    type: loki
    access: proxy
    url: http://loki:3100
    jsonData:
      maxLines: 1000
```

### Provisioning – Dashboards

Datei: `monitoring/grafana/provisioning/dashboards/dashboards.yml`

```yaml
apiVersion: 1

providers:
  - name: CAEMS Dashboards
    folder: CAEMS
    type: file
    options:
      path: /var/lib/grafana/dashboards
    updateIntervalSeconds: 30
    allowUiUpdates: true
```

### Dashboard: CAEMS Übersicht (JSON-Auszug)

Datei: `monitoring/grafana/dashboards/caems-overview.json`

```json
{
  "title": "CAEMS – Systemübersicht",
  "uid": "caems-overview",
  "tags": ["caems", "overview"],
  "refresh": "30s",
  "panels": [

    {
      "title": "HTTP Requests/s",
      "type": "timeseries",
      "gridPos": { "x": 0, "y": 0, "w": 12, "h": 8 },
      "targets": [{
        "expr": "rate(http_server_requests_seconds_count{application='caems-backend'}[1m])",
        "legendFormat": "{{method}} {{uri}} {{status}}"
      }]
    },

    {
      "title": "HTTP Latenz p99 (ms)",
      "type": "timeseries",
      "gridPos": { "x": 12, "y": 0, "w": 12, "h": 8 },
      "targets": [{
        "expr": "histogram_quantile(0.99, rate(http_server_requests_seconds_bucket{application='caems-backend'}[5m])) * 1000",
        "legendFormat": "p99 Latenz"
      }]
    },

    {
      "title": "Aktive Ausleihen",
      "type": "stat",
      "gridPos": { "x": 0, "y": 8, "w": 6, "h": 4 },
      "targets": [{
        "expr": "caems_loans_active"
      }]
    },

    {
      "title": "Lizenzauslastung (%)",
      "type": "bargauge",
      "gridPos": { "x": 6, "y": 8, "w": 18, "h": 4 },
      "targets": [{
        "expr": "caems_licenses_usage_percent",
        "legendFormat": "{{software}}"
      }],
      "fieldConfig": {
        "defaults": {
          "thresholds": {
            "steps": [
              { "value": 0,  "color": "green" },
              { "value": 80, "color": "yellow" },
              { "value": 90, "color": "red" }
            ]
          },
          "max": 100, "unit": "percent"
        }
      }
    },

    {
      "title": "JVM Heap-Nutzung",
      "type": "timeseries",
      "gridPos": { "x": 0, "y": 12, "w": 12, "h": 8 },
      "targets": [{
        "expr": "jvm_memory_used_bytes{area='heap', application='caems-backend'} / 1024 / 1024",
        "legendFormat": "Heap (MB)"
      }]
    },

    {
      "title": "DB Connection Pool",
      "type": "timeseries",
      "gridPos": { "x": 12, "y": 12, "w": 12, "h": 8 },
      "targets": [
        {
          "expr": "hikaricp_connections_active{application='caems-backend'}",
          "legendFormat": "Aktiv"
        },
        {
          "expr": "hikaricp_connections_idle{application='caems-backend'}",
          "legendFormat": "Idle"
        },
        {
          "expr": "hikaricp_connections_pending{application='caems-backend'}",
          "legendFormat": "Wartend"
        }
      ]
    },

    {
      "title": "Fehlerrate (%)",
      "type": "timeseries",
      "gridPos": { "x": 0, "y": 20, "w": 24, "h": 8 },
      "targets": [{
        "expr": "sum(rate(http_server_requests_seconds_count{status=~'5..', application='caems-backend'}[5m])) / sum(rate(http_server_requests_seconds_count{application='caems-backend'}[5m])) * 100",
        "legendFormat": "5xx Fehlerrate %"
      }],
      "fieldConfig": {
        "defaults": {
          "thresholds": {
            "steps": [
              { "value": 0,   "color": "green" },
              { "value": 1,   "color": "yellow" },
              { "value": 5,   "color": "red" }
            ]
          }
        }
      }
    }
  ]
}
```

**Empfohlene fertige Dashboards von grafana.com:**

| Dashboard | ID | Beschreibung |
|-----------|-----|-------------|
| Spring Boot Statistics | `12900` | JVM, HTTP, DB |
| PostgreSQL Database | `9628` | Queries, Connections |
| Node Exporter Full | `1860` | CPU, RAM, Disk, Network |
| Loki Dashboard | `13639` | Log-Analyse |

Import: Grafana → Dashboards → Import → ID eingeben

---

## 6. Loki – Log-Aggregation

### Loki Konfiguration

Datei: `monitoring/loki/config.yml`

```yaml
auth_enabled: false

server:
  http_listen_port: 3100
  grpc_listen_port: 9096

common:
  path_prefix: /loki
  storage:
    filesystem:
      chunks_directory: /loki/chunks
      rules_directory: /loki/rules
  replication_factor: 1
  ring:
    instance_addr: 127.0.0.1
    kvstore:
      store: inmemory

schema_config:
  configs:
    - from: 2024-01-01
      store: tsdb
      object_store: filesystem
      schema: v13
      index:
        prefix: index_
        period: 24h

limits_config:
  retention_period: 30d
  ingestion_rate_mb: 16
  ingestion_burst_size_mb: 32

compactor:
  working_directory: /loki/compactor
  retention_enabled: true
  retention_delete_delay: 2h
```

### Promtail Konfiguration

Datei: `monitoring/promtail/config.yml`

```yaml
server:
  http_listen_port: 9080

positions:
  filename: /tmp/positions.yaml

clients:
  - url: http://loki:3100/loki/api/v1/push

scrape_configs:

  # Alle Docker-Container automatisch
  - job_name: docker
    docker_sd_configs:
      - host: unix:///var/run/docker.sock
        refresh_interval: 5s
    relabel_configs:
      - source_labels: [__meta_docker_container_name]
        target_label: container
      - source_labels: [__meta_docker_container_label_com_docker_compose_service]
        target_label: service

  # CAEMS Backend spezifisch (JSON-Logs parsen)
  - job_name: caems-backend
    static_configs:
      - targets: [localhost]
        labels:
          job: caems-backend
          __path__: /var/lib/docker/containers/*caems-backend*/*.log
    pipeline_stages:
      - json:
          expressions:
            level:   level
            logger:  logger
            message: msg
      - labels:
          level:
          logger:
      - output:
          source: message
```

### Nützliche LogQL-Queries in Grafana

```logql
# Alle Fehler des Backends
{service="caems-backend"} |= "ERROR"

# HTTP 5xx Fehler
{service="caems-backend"} | json | level="ERROR" | line_format "{{.msg}}"

# Ausleihe-Events
{service="caems-backend"} |= "ausgeliehen"

# Slow Queries (> 1000ms)
{service="caems-backend"} | json | msg =~ ".*Hibernate.*" | duration > 1000ms

# Fehlerrate über Zeit
sum(rate({service="caems-backend"} |= "ERROR" [5m]))
```

---

## 7. Alertmanager – Benachrichtigungen

Datei: `monitoring/alertmanager/config.yml`

```yaml
global:
  resolve_timeout: 5m
  slack_api_url: ${SLACK_WEBHOOK_URL}

route:
  group_by: [alertname, service]
  group_wait:      30s
  group_interval:  5m
  repeat_interval: 4h
  receiver: default

  routes:
    # Kritische Alerts → sofort & Slack + E-Mail
    - match:
        severity: critical
      receiver: critical
      repeat_interval: 1h

    # Backend-Fehler → Slack Dev-Channel
    - match:
        service: caems-backend
      receiver: backend-team

    # DB-Probleme → DBA-Channel
    - match:
        service: postgres
      receiver: dba-team

receivers:

  - name: default
    slack_configs:
      - channel: '#caems-alerts'
        title: '{{ .GroupLabels.alertname }}'
        text: >-
          {{ range .Alerts }}
          *Alert:* {{ .Annotations.summary }}
          *Details:* {{ .Annotations.description }}
          *Schweregrad:* {{ .Labels.severity }}
          {{ end }}
        color: '{{ if eq .Status "firing" }}danger{{ else }}good{{ end }}'

  - name: critical
    slack_configs:
      - channel: '#caems-critical'
        title: '🚨 KRITISCH: {{ .GroupLabels.alertname }}'
        text: '{{ range .Alerts }}{{ .Annotations.description }}{{ end }}'
    email_configs:
      - to: oncall@firma.de
        from: alerts@firma.de
        smarthost: smtp.firma.de:587
        auth_username: alerts@firma.de
        auth_password: ${SMTP_PASSWORD}
        headers:
          Subject: '[CAEMS KRITISCH] {{ .GroupLabels.alertname }}'

  - name: backend-team
    slack_configs:
      - channel: '#team-backend'
        title: '⚠️ Backend Alert'
        text: '{{ range .Alerts }}{{ .Annotations.summary }}{{ end }}'

  - name: dba-team
    slack_configs:
      - channel: '#team-dba'
        title: '🐘 Datenbank Alert'
        text: '{{ range .Alerts }}{{ .Annotations.summary }}{{ end }}'

inhibit_rules:
  # Wenn kritisch feuert → Warnings unterdrücken
  - source_match:
      severity: critical
    target_match:
      severity: warning
    equal: [alertname, service]
```

---

## 8. Alert-Regeln

Datei: `monitoring/prometheus/rules/caems-alerts.yml`

```yaml
groups:

  # ── Backend-Alerts ───────────────────────────────────────
  - name: caems-backend
    interval: 30s
    rules:

      - alert: BackendDown
        expr: up{job="caems-backend"} == 0
        for: 1m
        labels:
          severity: critical
          service: caems-backend
        annotations:
          summary: "CAEMS Backend nicht erreichbar"
          description: "Der Backend-Service ist seit > 1 Minute nicht erreichbar."

      - alert: HighErrorRate
        expr: |
          sum(rate(http_server_requests_seconds_count{
            status=~"5..", application="caems-backend"
          }[5m]))
          /
          sum(rate(http_server_requests_seconds_count{
            application="caems-backend"
          }[5m])) * 100 > 5
        for: 2m
        labels:
          severity: critical
          service: caems-backend
        annotations:
          summary: "Hohe Fehlerrate im Backend"
          description: "5xx-Fehlerrate liegt bei {{ printf \"%.1f\" $value }}% (Schwellenwert: 5%)."

      - alert: HighLatency
        expr: |
          histogram_quantile(0.99,
            rate(http_server_requests_seconds_bucket{
              application="caems-backend"
            }[5m])
          ) * 1000 > 2000
        for: 3m
        labels:
          severity: warning
          service: caems-backend
        annotations:
          summary: "Hohe API-Latenz"
          description: "p99-Latenz liegt bei {{ printf \"%.0f\" $value }}ms (Schwellenwert: 2000ms)."

      - alert: HighJvmHeap
        expr: |
          jvm_memory_used_bytes{area="heap", application="caems-backend"}
          /
          jvm_memory_max_bytes{area="heap", application="caems-backend"} * 100 > 85
        for: 5m
        labels:
          severity: warning
          service: caems-backend
        annotations:
          summary: "JVM Heap-Auslastung hoch"
          description: "Heap-Nutzung liegt bei {{ printf \"%.0f\" $value }}% (Schwellenwert: 85%)."

      - alert: DbConnectionPoolExhausted
        expr: |
          hikaricp_connections_pending{application="caems-backend"} > 5
        for: 2m
        labels:
          severity: critical
          service: caems-backend
        annotations:
          summary: "DB Connection Pool erschöpft"
          description: "{{ $value }} Threads warten auf eine DB-Verbindung."

  # ── PostgreSQL-Alerts ────────────────────────────────────
  - name: postgres
    rules:

      - alert: PostgresDown
        expr: up{job="postgres"} == 0
        for: 1m
        labels:
          severity: critical
          service: postgres
        annotations:
          summary: "PostgreSQL nicht erreichbar"
          description: "PostgreSQL ist seit > 1 Minute nicht erreichbar."

      - alert: PostgresHighConnections
        expr: |
          pg_stat_database_numbackends{datname="caems"}
          / pg_settings_max_connections * 100 > 80
        for: 5m
        labels:
          severity: warning
          service: postgres
        annotations:
          summary: "Viele DB-Verbindungen"
          description: "{{ printf \"%.0f\" $value }}% der max. Verbindungen sind belegt."

  # ── Business-Alerts ──────────────────────────────────────
  - name: caems-business
    rules:

      - alert: LicenseCapacityCritical
        expr: caems_licenses_usage_percent > 95
        for: 10m
        labels:
          severity: warning
          service: caems-backend
        annotations:
          summary: "Lizenzkapazität kritisch"
          description: "Software '{{ $labels.software }}' ist zu {{ printf \"%.0f\" $value }}% ausgelastet."

  # ── Server-Alerts ────────────────────────────────────────
  - name: node
    rules:

      - alert: HighCpuUsage
        expr: 100 - (avg by(instance) (rate(node_cpu_seconds_total{mode="idle"}[5m])) * 100) > 85
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "Hohe CPU-Auslastung"
          description: "CPU-Auslastung liegt bei {{ printf \"%.0f\" $value }}%."

      - alert: DiskSpaceLow
        expr: |
          (node_filesystem_avail_bytes{mountpoint="/"}
          / node_filesystem_size_bytes{mountpoint="/"}) * 100 < 15
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "Wenig Festplattenplatz"
          description: "Nur noch {{ printf \"%.0f\" $value }}% Festplattenplatz verfügbar."
```

---

## 9. GitHub Actions – Monitoring-Integration

Datei: `.github/workflows/monitoring-check.yml`

```yaml
name: Monitoring Health Check

on:
  schedule:
    - cron: "*/15 * * * *"   # alle 15 Minuten
  workflow_dispatch:

jobs:
  health-check:
    name: 🩺 Monitoring Stack prüfen
    runs-on: ubuntu-latest

    steps:
      - name: Prometheus Health
        run: |
          STATUS=$(curl -s -o /dev/null -w "%{http_code}" \
            ${{ secrets.PROMETHEUS_URL }}/-/healthy)
          echo "Prometheus: HTTP $STATUS"
          [ "$STATUS" = "200" ] || exit 1

      - name: Grafana Health
        run: |
          STATUS=$(curl -s -o /dev/null -w "%{http_code}" \
            ${{ secrets.GRAFANA_URL }}/api/health)
          echo "Grafana: HTTP $STATUS"
          [ "$STATUS" = "200" ] || exit 1

      - name: Backend Actuator Health
        run: |
          STATUS=$(curl -s -o /dev/null -w "%{http_code}" \
            ${{ secrets.BACKEND_URL }}/actuator/health)
          echo "Backend: HTTP $STATUS"
          [ "$STATUS" = "200" ] || exit 1

      - name: Slack Benachrichtigung bei Fehler
        if: failure()
        uses: slackapi/slack-github-action@v1
        with:
          payload: |
            {
              "text": "🚨 CAEMS Monitoring Health Check FEHLGESCHLAGEN!\nWorkflow: ${{ github.server_url }}/${{ github.repository }}/actions/runs/${{ github.run_id }}"
            }
        env:
          SLACK_WEBHOOK_URL: ${{ secrets.SLACK_WEBHOOK_URL }}
          SLACK_WEBHOOK_TYPE: INCOMING_WEBHOOK
```

---

## 10. Ports & URLs Übersicht

| Service | URL | Zugangsdaten |
|---------|-----|-------------|
| **Grafana** | http://localhost:3001 | admin / admin123 (ändern!) |
| **Prometheus** | http://localhost:9090 | — |
| **Alertmanager** | http://localhost:9093 | — |
| **Loki** | http://localhost:3100 | — |
| **Actuator Health** | http://localhost:8080/actuator/health | — |
| **Actuator Metrics** | http://localhost:8080/actuator/prometheus | — |
| **Swagger UI** | http://localhost:8080/swagger-ui.html | — |

### Schnellstart

```bash
# 1. Monitoring-Stack starten
docker compose \
  -f docker-compose.yml \
  -f docker-compose.monitoring.yml \
  up -d

# 2. Status prüfen
docker compose ps

# 3. Grafana öffnen
open http://localhost:3001

# 4. Fertige Dashboards importieren (IDs):
#    Spring Boot: 12900
#    PostgreSQL:   9628
#    Node Exporter: 1860
#    Loki:         13639
```

### Verzeichnisstruktur

```
caems/
├── docker-compose.monitoring.yml
└── monitoring/
    ├── prometheus/
    │   ├── prometheus.yml
    │   └── rules/
    │       └── caems-alerts.yml
    ├── grafana/
    │   ├── provisioning/
    │   │   ├── datasources/datasources.yml
    │   │   └── dashboards/dashboards.yml
    │   └── dashboards/
    │       └── caems-overview.json
    ├── loki/
    │   └── config.yml
    ├── promtail/
    │   └── config.yml
    └── alertmanager/
        └── config.yml
```
