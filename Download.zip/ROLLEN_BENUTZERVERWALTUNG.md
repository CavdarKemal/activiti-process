# CAEMS – Rollen & Benutzerverwaltung (Admin-UI)

---

## Inhaltsverzeichnis

1. [Rollenmodell](#1-rollenmodell)
2. [Backend – Rollen & Benutzer](#2-backend--rollen--benutzer)
3. [Spring Security – Method-Level Security](#3-spring-security--method-level-security)
4. [Admin-UI – React Komponenten](#4-admin-ui--react-komponenten)
5. [Datenbankschema](#5-datenbankschema)
6. [API-Endpunkte](#6-api-endpunkte)
7. [Tests](#7-tests)

---

## 1. Rollenmodell

| Rolle | Beschreibung | Berechtigungen |
|-------|-------------|---------------|
| **ADMIN** | Vollzugriff | Alles |
| **HR** | Personal-Abteilung | Mitarbeiter lesen/schreiben, Gehalt sehen |
| **IT** | IT-Abteilung | Hardware lesen/schreiben, Ausleihe, Software lesen |
| **VIEWER** | Lesezugriff | Alles lesen, nichts schreiben |

### Berechtigungs-Matrix

| Aktion | ADMIN | HR | IT | VIEWER |
|--------|-------|----|----|--------|
| Mitarbeiter anlegen/bearbeiten | ✅ | ✅ | ❌ | ❌ |
| Gehalt sehen | ✅ | ✅ | ❌ | ❌ |
| Hardware verwalten | ✅ | ❌ | ✅ | ❌ |
| Hardware ausleihen/zurückgeben | ✅ | ❌ | ✅ | ❌ |
| Software & Lizenzen verwalten | ✅ | ❌ | ✅ | ❌ |
| Benutzer verwalten | ✅ | ❌ | ❌ | ❌ |
| Audit-Log lesen | ✅ | ✅ | ✅ | ❌ |

---

## 2. Backend – Rollen & Benutzer

### AppUser.java (Entity)

```java
package com.caems.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDateTime;
import java.util.*;

@Entity
@Table(name = "app_users")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AppUser implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, length = 255)
    @Email
    @NotBlank
    private String email;

    @Column(nullable = false)
    @NotBlank
    private String passwordHash;

    @Column(nullable = false, length = 100)
    @NotBlank
    private String displayName;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private Role role = Role.VIEWER;

    @Builder.Default
    private boolean enabled = true;

    @Builder.Default
    private boolean accountNonLocked = true;

    // Verknüpfung zum Mitarbeiter (optional)
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id")
    private Employee linkedEmployee;

    @Column(name = "last_login_at")
    private LocalDateTime lastLoginAt;

    @Column(name = "password_changed_at")
    private LocalDateTime passwordChangedAt;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    // ── UserDetails Interface ──────────────────────────────
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_" + role.name()));
    }

    @Override public String getPassword()   { return passwordHash; }
    @Override public String getUsername()   { return email; }
    @Override public boolean isEnabled()    { return enabled; }
    @Override public boolean isAccountNonLocked() { return accountNonLocked; }
    @Override public boolean isAccountNonExpired() { return true; }
    @Override public boolean isCredentialsNonExpired() { return true; }

    public enum Role { ADMIN, HR, IT, VIEWER }
}
```

### UserRepository.java

```java
package com.caems.repository;

import com.caems.model.AppUser;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface UserRepository extends JpaRepository<AppUser, Long> {

    Optional<AppUser> findByEmail(String email);

    boolean existsByEmail(String email);

    @Query("""
        SELECT u FROM AppUser u
        WHERE :search IS NULL OR
              LOWER(u.email)       LIKE LOWER(CONCAT('%', :search, '%')) OR
              LOWER(u.displayName) LIKE LOWER(CONCAT('%', :search, '%'))
        """)
    Page<AppUser> search(@Param("search") String search, Pageable pageable);

    long countByRole(AppUser.Role role);
}
```

### UserService.java

```java
package com.caems.service;

import com.caems.dto.CreateUserDTO;
import com.caems.dto.UpdateUserDTO;
import com.caems.dto.UserDTO;
import com.caems.exception.BusinessException;
import com.caems.exception.ResourceNotFoundException;
import com.caems.model.AppUser;
import com.caems.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class UserService implements UserDetailsService {

    private final UserRepository userRepo;
    private final PasswordEncoder passwordEncoder;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        return userRepo.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("Benutzer nicht gefunden: " + email));
    }

    @Transactional(readOnly = true)
    public Page<UserDTO> findAll(Pageable pageable, String search) {
        return userRepo.search(search, pageable).map(this::toDTO);
    }

    public UserDTO createUser(CreateUserDTO dto) {
        if (userRepo.existsByEmail(dto.getEmail()))
            throw new BusinessException("E-Mail bereits vergeben: " + dto.getEmail());

        AppUser user = AppUser.builder()
                .email(dto.getEmail())
                .displayName(dto.getDisplayName())
                .passwordHash(passwordEncoder.encode(dto.getInitialPassword()))
                .role(dto.getRole())
                .passwordChangedAt(LocalDateTime.now())
                .build();

        AppUser saved = userRepo.save(user);
        log.info("Benutzer angelegt: {} mit Rolle {}", saved.getEmail(), saved.getRole());
        return toDTO(saved);
    }

    public UserDTO updateRole(Long userId, AppUser.Role newRole) {
        AppUser user = userRepo.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Benutzer", userId));

        // Letzten Admin schützen
        if (user.getRole() == AppUser.Role.ADMIN && newRole != AppUser.Role.ADMIN) {
            long adminCount = userRepo.countByRole(AppUser.Role.ADMIN);
            if (adminCount <= 1)
                throw new BusinessException("Mindestens ein ADMIN muss vorhanden bleiben.");
        }

        AppUser.Role oldRole = user.getRole();
        user.setRole(newRole);
        log.info("Rolle geändert für {}: {} → {}", user.getEmail(), oldRole, newRole);
        return toDTO(userRepo.save(user));
    }

    public void toggleLock(Long userId) {
        AppUser user = userRepo.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Benutzer", userId));

        // Eigenen Account nicht sperren
        String currentUser = SecurityContextHolder.getContext()
                .getAuthentication().getName();
        if (user.getEmail().equals(currentUser))
            throw new BusinessException("Eigenen Account kann man nicht sperren.");

        user.setAccountNonLocked(!user.isAccountNonLocked());
        log.info("Account {} gesperrt: {}", user.getEmail(), !user.isAccountNonLocked());
        userRepo.save(user);
    }

    public void resetPassword(Long userId, String newPassword) {
        AppUser user = userRepo.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Benutzer", userId));
        user.setPasswordHash(passwordEncoder.encode(newPassword));
        user.setPasswordChangedAt(LocalDateTime.now());
        userRepo.save(user);
        log.info("Passwort zurückgesetzt für: {}", user.getEmail());
    }

    public void recordLogin(String email) {
        userRepo.findByEmail(email).ifPresent(u -> {
            u.setLastLoginAt(LocalDateTime.now());
            userRepo.save(u);
        });
    }

    private UserDTO toDTO(AppUser u) {
        UserDTO dto = new UserDTO();
        dto.setId(u.getId());
        dto.setEmail(u.getEmail());
        dto.setDisplayName(u.getDisplayName());
        dto.setRole(u.getRole());
        dto.setEnabled(u.isEnabled());
        dto.setAccountNonLocked(u.isAccountNonLocked());
        dto.setLastLoginAt(u.getLastLoginAt());
        dto.setCreatedAt(u.getCreatedAt());
        return dto;
    }
}
```

### UserController.java

```java
package com.caems.controller;

import com.caems.dto.*;
import com.caems.model.AppUser;
import com.caems.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin/users")
@RequiredArgsConstructor
@Tag(name = "Admin – Benutzerverwaltung")
@PreAuthorize("hasRole('ADMIN')")     // gesamter Controller nur für ADMIN
public class UserController {

    private final UserService userService;

    @GetMapping
    @Operation(summary = "Alle Benutzer (paginiert)")
    public Page<UserDTO> getAll(
            @PageableDefault(size = 20, sort = "email") Pageable pageable,
            @RequestParam(required = false) String search) {
        return userService.findAll(pageable, search);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Benutzer anlegen")
    public UserDTO create(@Valid @RequestBody CreateUserDTO dto) {
        return userService.createUser(dto);
    }

    @PatchMapping("/{id}/role")
    @Operation(summary = "Rolle ändern")
    public UserDTO updateRole(
            @PathVariable Long id,
            @RequestParam AppUser.Role role) {
        return userService.updateRole(id, role);
    }

    @PatchMapping("/{id}/toggle-lock")
    @Operation(summary = "Account sperren / entsperren")
    public ResponseEntity<Void> toggleLock(@PathVariable Long id) {
        userService.toggleLock(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/reset-password")
    @Operation(summary = "Passwort zurücksetzen")
    public ResponseEntity<Void> resetPassword(
            @PathVariable Long id,
            @RequestParam String newPassword) {
        userService.resetPassword(id, newPassword);
        return ResponseEntity.noContent().build();
    }
}
```

---

## 3. Spring Security – Method-Level Security

```java
// Nur ADMIN und HR dürfen Gehalt sehen
@GetMapping("/{id}")
public ResponseEntity<EmployeeDTO> getEmployee(
        @PathVariable Long id,
        Authentication auth) {

    EmployeeDTO dto = employeeService.findById(id);

    // Gehalt nur für ADMIN und HR
    boolean canSeeSalary = auth.getAuthorities().stream()
            .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN")
                       || a.getAuthority().equals("ROLE_HR"));
    if (!canSeeSalary) {
        dto.setSalary(null);
    }
    return ResponseEntity.ok(dto);
}

// Ausleihe nur für ADMIN und IT
@PostMapping("/hardware/{hardwareId}/loan")
@PreAuthorize("hasAnyRole('ADMIN', 'IT')")
public ResponseEntity<LoanDTO> loanHardware(...) { ... }

// Benutzer-Verwaltung nur für ADMIN
@PreAuthorize("hasRole('ADMIN')")
public UserDTO createUser(...) { ... }

// Lesender Zugriff für alle authentifizierten Rollen
@GetMapping
@PreAuthorize("isAuthenticated()")
public Page<EmployeeDTO> getAll(...) { ... }
```

---

## 4. Admin-UI – React Komponenten

### Flyout: Admin-Navigation

```jsx
// Zeigt Admin-Menü nur für ADMIN-Rolle
function AdminNav({ user }) {
  if (user?.role !== "ADMIN") return null;

  return (
    <div style={{ borderTop: "1px solid rgba(255,255,255,.1)", padding: "10px" }}>
      <button
        onClick={() => setPage("admin")}
        style={{
          width: "100%", padding: "9px 12px", borderRadius: 9, border: "none",
          background: "rgba(239,68,68,.15)", color: "#fca5a5",
          display: "flex", alignItems: "center", gap: 10,
          cursor: "pointer", fontSize: 13, fontWeight: 600,
        }}>
        🔐 Benutzerverwaltung
      </button>
    </div>
  );
}
```

### AdminPage.jsx (vollständig)

```jsx
import { useState, useEffect } from "react";

const ROLES = ["ADMIN", "HR", "IT", "VIEWER"];

const ROLE_CONFIG = {
  ADMIN:  { color: "#dc2626", bg: "#fee2e2", label: "Admin" },
  HR:     { color: "#d97706", bg: "#fef3c7", label: "HR" },
  IT:     { color: "#2563eb", bg: "#dbeafe", label: "IT" },
  VIEWER: { color: "#6b7280", bg: "#f3f4f6", label: "Viewer" },
};

// Simulierte Benutzerdaten
const MOCK_USERS = [
  { id:1, email:"admin@firma.de", displayName:"System Admin", role:"ADMIN",
    enabled:true, accountNonLocked:true, lastLoginAt:"2024-12-01T09:15:00", createdAt:"2024-01-01" },
  { id:2, email:"hr.meyer@firma.de", displayName:"Maria Meyer", role:"HR",
    enabled:true, accountNonLocked:true, lastLoginAt:"2024-12-01T08:30:00", createdAt:"2024-03-15" },
  { id:3, email:"it.schmidt@firma.de", displayName:"Klaus Schmidt", role:"IT",
    enabled:true, accountNonLocked:true, lastLoginAt:"2024-11-30T14:20:00", createdAt:"2024-02-10" },
  { id:4, email:"view.only@firma.de", displayName:"Leser Müller", role:"VIEWER",
    enabled:true, accountNonLocked:false, lastLoginAt:null, createdAt:"2024-06-01" },
];

export function AdminPage({ toast }) {
  const [users, setUsers]         = useState(MOCK_USERS);
  const [search, setSearch]       = useState("");
  const [showForm, setShowForm]   = useState(false);
  const [selected, setSelected]   = useState(null);
  const [confirmAction, setConfirm] = useState(null);

  const filtered = users.filter(u =>
    `${u.email} ${u.displayName}`.toLowerCase().includes(search.toLowerCase())
  );

  const handleRoleChange = (userId, newRole) => {
    setUsers(u => u.map(usr => usr.id === userId ? { ...usr, role: newRole } : usr));
    toast(`Rolle erfolgreich geändert auf ${newRole} ✅`);
  };

  const handleToggleLock = (userId) => {
    setUsers(u => u.map(usr =>
      usr.id === userId
        ? { ...usr, accountNonLocked: !usr.accountNonLocked }
        : usr
    ));
    const user = users.find(u => u.id === userId);
    toast(user.accountNonLocked ? "Account gesperrt 🔒" : "Account entsperrt 🔓");
    setConfirm(null);
  };

  const handleCreate = (newUser) => {
    setUsers(u => [...u, { ...newUser, id: Date.now(), createdAt: new Date().toISOString() }]);
    toast("Benutzer angelegt ✅");
    setShowForm(false);
  };

  const roleCounts = ROLES.reduce((acc, r) => ({
    ...acc, [r]: users.filter(u => u.role === r).length
  }), {});

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>

      {/* Rollen-Übersicht */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10 }}>
        {ROLES.map(role => (
          <div key={role} style={{
            background: "#fff", border: "1px solid #e5e7eb", borderRadius: 12,
            padding: "14px 16px", display: "flex", alignItems: "center", gap: 12,
          }}>
            <div style={{
              width: 40, height: 40, borderRadius: 10,
              background: ROLE_CONFIG[role].bg, color: ROLE_CONFIG[role].color,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 20, fontWeight: 700,
            }}>
              {ROLE_CONFIG[role].label[0]}
            </div>
            <div>
              <div style={{ fontSize: 22, fontWeight: 800 }}>{roleCounts[role]}</div>
              <div style={{ fontSize: 11, color: "#6b7280" }}>{ROLE_CONFIG[role].label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Toolbar */}
      <div style={{ display: "flex", gap: 10 }}>
        <input
          value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Benutzer suchen …"
          style={{ flex: 1, padding: "9px 12px", borderRadius: 9,
            border: "1px solid #e5e7eb", fontSize: 13, outline: "none" }}
        />
        <button
          onClick={() => setShowForm(true)}
          style={{ padding: "9px 18px", background: "#4f46e5", color: "#fff",
            border: "none", borderRadius: 9, fontSize: 13, fontWeight: 600, cursor: "pointer" }}>
          ＋ Benutzer
        </button>
      </div>

      {/* Benutzertabelle */}
      <div style={{ background: "#fff", border: "1px solid #e5e7eb", borderRadius: 12, overflow: "hidden" }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead style={{ background: "#f9fafb" }}>
            <tr style={{ fontSize: 11, color: "#6b7280", fontWeight: 700,
              textTransform: "uppercase", letterSpacing: "0.5px" }}>
              {["Benutzer", "Rolle", "Status", "Letzter Login", "Erstellt", "Aktionen"].map(h => (
                <th key={h} style={{ padding: "12px 16px", textAlign: "left",
                  borderBottom: "1px solid #e5e7eb" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((user, i) => {
              const rc = ROLE_CONFIG[user.role];
              return (
                <tr key={user.id} style={{
                  borderBottom: i < filtered.length - 1 ? "1px solid #f3f4f6" : "none",
                  background: !user.accountNonLocked ? "#fef2f2" : "transparent",
                }}>
                  {/* Benutzer */}
                  <td style={{ padding: "12px 16px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <div style={{
                        width: 36, height: 36, borderRadius: 18,
                        background: rc.bg, color: rc.color,
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: 14, fontWeight: 700,
                      }}>
                        {user.displayName[0]}
                      </div>
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 600 }}>{user.displayName}</div>
                        <div style={{ fontSize: 11, color: "#6b7280" }}>{user.email}</div>
                      </div>
                    </div>
                  </td>

                  {/* Rolle (änderbar) */}
                  <td style={{ padding: "12px 16px" }}>
                    <select
                      value={user.role}
                      onChange={e => handleRoleChange(user.id, e.target.value)}
                      disabled={user.id === 1} // System-Admin schützen
                      style={{
                        padding: "4px 10px", borderRadius: 8,
                        border: `1.5px solid ${rc.color}`,
                        background: rc.bg, color: rc.color,
                        fontSize: 12, fontWeight: 600, cursor: "pointer",
                        opacity: user.id === 1 ? 0.5 : 1,
                      }}>
                      {ROLES.map(r => (
                        <option key={r} value={r}>{ROLE_CONFIG[r].label}</option>
                      ))}
                    </select>
                  </td>

                  {/* Status */}
                  <td style={{ padding: "12px 16px" }}>
                    <span style={{
                      padding: "3px 10px", borderRadius: 20, fontSize: 11, fontWeight: 600,
                      background: user.accountNonLocked ? "#d1fae5" : "#fee2e2",
                      color: user.accountNonLocked ? "#059669" : "#dc2626",
                    }}>
                      {user.accountNonLocked ? "✅ Aktiv" : "🔒 Gesperrt"}
                    </span>
                  </td>

                  {/* Letzter Login */}
                  <td style={{ padding: "12px 16px", fontSize: 12, color: "#6b7280" }}>
                    {user.lastLoginAt
                      ? new Date(user.lastLoginAt).toLocaleString("de-DE")
                      : "Noch nie"}
                  </td>

                  {/* Erstellt */}
                  <td style={{ padding: "12px 16px", fontSize: 12, color: "#6b7280" }}>
                    {new Date(user.createdAt).toLocaleDateString("de-DE")}
                  </td>

                  {/* Aktionen */}
                  <td style={{ padding: "12px 16px" }}>
                    <div style={{ display: "flex", gap: 6 }}>
                      <button
                        onClick={() => setConfirm({ type: "lock", user })}
                        disabled={user.id === 1}
                        title={user.accountNonLocked ? "Sperren" : "Entsperren"}
                        style={{
                          padding: "5px 10px", borderRadius: 7,
                          border: "1px solid #e5e7eb", background: "#fff",
                          cursor: user.id === 1 ? "not-allowed" : "pointer",
                          fontSize: 13, opacity: user.id === 1 ? 0.4 : 1,
                        }}>
                        {user.accountNonLocked ? "🔒" : "🔓"}
                      </button>
                      <button
                        onClick={() => setConfirm({ type: "password", user })}
                        title="Passwort zurücksetzen"
                        style={{
                          padding: "5px 10px", borderRadius: 7,
                          border: "1px solid #e5e7eb", background: "#fff",
                          cursor: "pointer", fontSize: 13,
                        }}>
                        🔑
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Benutzer anlegen Modal */}
      {showForm && (
        <CreateUserModal onSave={handleCreate} onClose={() => setShowForm(false)} />
      )}

      {/* Bestätigungs-Dialog */}
      {confirmAction && (
        <ConfirmDialog
          action={confirmAction}
          onConfirm={() => {
            if (confirmAction.type === "lock") handleToggleLock(confirmAction.user.id);
          }}
          onClose={() => setConfirm(null)}
        />
      )}
    </div>
  );
}

function CreateUserModal({ onSave, onClose }) {
  const [form, setForm] = useState({
    email: "", displayName: "", role: "VIEWER", initialPassword: ""
  });
  const [errors, setErrors] = useState({});

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const validate = () => {
    const e = {};
    if (!form.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))
      e.email = "Gültige E-Mail erforderlich";
    if (!form.displayName) e.displayName = "Pflichtfeld";
    if (!form.initialPassword || form.initialPassword.length < 8)
      e.initialPassword = "Mindestens 8 Zeichen";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSave = () => {
    if (!validate()) return;
    onSave({ ...form, enabled: true, accountNonLocked: true, lastLoginAt: null });
  };

  const inputStyle = (err) => ({
    width: "100%", padding: "9px 12px", borderRadius: 8,
    border: `1.5px solid ${err ? "#dc2626" : "#e5e7eb"}`,
    fontSize: 13, outline: "none", boxSizing: "border-box",
  });

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.45)",
      zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
      <div style={{ background: "#fff", borderRadius: 16, width: "100%", maxWidth: 440,
        overflow: "hidden", boxShadow: "0 20px 60px rgba(0,0,0,.25)" }}>
        <div style={{ padding: "18px 22px", borderBottom: "1px solid #e5e7eb",
          display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700 }}>Neuer Benutzer</h3>
          <button onClick={onClose} style={{ border: "none", background: "none",
            cursor: "pointer", fontSize: 20, color: "#6b7280" }}>×</button>
        </div>
        <div style={{ padding: 22, display: "flex", flexDirection: "column", gap: 14 }}>
          <div>
            <label style={{ fontSize: 12, fontWeight: 600, display: "block", marginBottom: 5 }}>
              E-Mail *
            </label>
            <input value={form.email} onChange={e => set("email", e.target.value)}
              placeholder="name@firma.de" style={inputStyle(errors.email)} />
            {errors.email && <div style={{ fontSize: 11, color: "#dc2626", marginTop: 4 }}>{errors.email}</div>}
          </div>

          <div>
            <label style={{ fontSize: 12, fontWeight: 600, display: "block", marginBottom: 5 }}>
              Anzeigename *
            </label>
            <input value={form.displayName} onChange={e => set("displayName", e.target.value)}
              placeholder="Max Mustermann" style={inputStyle(errors.displayName)} />
            {errors.displayName && <div style={{ fontSize: 11, color: "#dc2626", marginTop: 4 }}>{errors.displayName}</div>}
          </div>

          <div>
            <label style={{ fontSize: 12, fontWeight: 600, display: "block", marginBottom: 5 }}>Rolle</label>
            <select value={form.role} onChange={e => set("role", e.target.value)}
              style={{ ...inputStyle(false), cursor: "pointer" }}>
              {ROLES.map(r => (
                <option key={r} value={r}>{ROLE_CONFIG[r].label} – {getRoleDescription(r)}</option>
              ))}
            </select>
          </div>

          <div>
            <label style={{ fontSize: 12, fontWeight: 600, display: "block", marginBottom: 5 }}>
              Initiales Passwort *
            </label>
            <input type="password" value={form.initialPassword}
              onChange={e => set("initialPassword", e.target.value)}
              placeholder="Mindestens 8 Zeichen" style={inputStyle(errors.initialPassword)} />
            {errors.initialPassword && <div style={{ fontSize: 11, color: "#dc2626", marginTop: 4 }}>{errors.initialPassword}</div>}
            <div style={{ fontSize: 11, color: "#6b7280", marginTop: 4 }}>
              Der Benutzer sollte das Passwort beim ersten Login ändern.
            </div>
          </div>

          {/* Rollen-Info */}
          <div style={{ background: "#f8fafc", borderRadius: 9, padding: "10px 12px",
            fontSize: 12, color: "#374151", border: "1px solid #e5e7eb" }}>
            <strong>{ROLE_CONFIG[form.role].label}:</strong> {getRoleDescription(form.role)}
          </div>
        </div>

        <div style={{ padding: "0 22px 22px", display: "flex", justifyContent: "flex-end", gap: 10 }}>
          <button onClick={onClose} style={{ padding: "9px 16px", borderRadius: 8,
            border: "1px solid #e5e7eb", background: "#fff", cursor: "pointer", fontSize: 13 }}>
            Abbrechen
          </button>
          <button onClick={handleSave} style={{ padding: "9px 18px", borderRadius: 8,
            background: "#4f46e5", color: "#fff", border: "none", cursor: "pointer",
            fontSize: 13, fontWeight: 600 }}>
            Anlegen
          </button>
        </div>
      </div>
    </div>
  );
}

function ConfirmDialog({ action, onConfirm, onClose }) {
  const isLock = action.type === "lock";
  const willLock = action.user.accountNonLocked;

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.45)",
      zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ background: "#fff", borderRadius: 14, padding: 28, maxWidth: 380,
        boxShadow: "0 20px 60px rgba(0,0,0,.25)", textAlign: "center" }}>
        <div style={{ fontSize: 40, marginBottom: 14 }}>
          {isLock && willLock ? "🔒" : "🔓"}
        </div>
        <h3 style={{ margin: "0 0 8px", fontSize: 16, fontWeight: 700 }}>
          {isLock && willLock ? "Account sperren?" : "Account entsperren?"}
        </h3>
        <p style={{ color: "#6b7280", fontSize: 13, margin: "0 0 20px" }}>
          {willLock
            ? `${action.user.displayName} kann sich nach dem Sperren nicht mehr anmelden.`
            : `${action.user.displayName} erhält wieder Zugang zum System.`}
        </p>
        <div style={{ display: "flex", gap: 10, justifyContent: "center" }}>
          <button onClick={onClose} style={{ padding: "9px 18px", borderRadius: 8,
            border: "1px solid #e5e7eb", background: "#fff", cursor: "pointer", fontSize: 13 }}>
            Abbrechen
          </button>
          <button onClick={onConfirm} style={{ padding: "9px 18px", borderRadius: 8,
            background: willLock ? "#dc2626" : "#059669", color: "#fff",
            border: "none", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>
            {willLock ? "Sperren" : "Entsperren"}
          </button>
        </div>
      </div>
    </div>
  );
}

function getRoleDescription(role) {
  const desc = {
    ADMIN:  "Vollzugriff auf alle Funktionen",
    HR:     "Mitarbeiterdaten lesen und bearbeiten",
    IT:     "Hardware und Software verwalten",
    VIEWER: "Nur lesender Zugriff",
  };
  return desc[role] || "";
}
```

---

## 5. Datenbankschema

Flyway-Migration: `V5__create_app_users.sql`

```sql
CREATE TABLE app_users (
    id                  BIGSERIAL PRIMARY KEY,
    email               VARCHAR(255) UNIQUE NOT NULL,
    password_hash       VARCHAR(255) NOT NULL,
    display_name        VARCHAR(100) NOT NULL,
    role                VARCHAR(20)  NOT NULL DEFAULT 'VIEWER',
    enabled             BOOLEAN      NOT NULL DEFAULT TRUE,
    account_non_locked  BOOLEAN      NOT NULL DEFAULT TRUE,
    employee_id         BIGINT REFERENCES employees(id) ON DELETE SET NULL,
    last_login_at       TIMESTAMP,
    password_changed_at TIMESTAMP,
    created_at          TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_users_email ON app_users(email);
CREATE INDEX idx_users_role  ON app_users(role);

-- Standard-Admin anlegen (Passwort: admin123 → BCrypt-Hash)
INSERT INTO app_users (email, password_hash, display_name, role)
VALUES (
    'admin@firma.de',
    '$2a$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    'System Administrator',
    'ADMIN'
);
```

---

## 6. API-Endpunkte

| Methode | Pfad | Rolle | Beschreibung |
|---------|------|-------|-------------|
| `GET` | `/api/v1/admin/users` | ADMIN | Alle Benutzer (paginiert) |
| `POST` | `/api/v1/admin/users` | ADMIN | Benutzer anlegen |
| `PATCH` | `/api/v1/admin/users/{id}/role` | ADMIN | Rolle ändern |
| `PATCH` | `/api/v1/admin/users/{id}/toggle-lock` | ADMIN | Sperren/Entsperren |
| `PATCH` | `/api/v1/admin/users/{id}/reset-password` | ADMIN | Passwort zurücksetzen |

---

## 7. Tests

### UserServiceTest.java (Unit)

```java
@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock UserRepository userRepo;
    @Mock PasswordEncoder passwordEncoder;
    @InjectMocks UserService userService;

    @Test
    @DisplayName("createUser – Erfolg")
    void createUser_success() {
        CreateUserDTO dto = new CreateUserDTO();
        dto.setEmail("neu@firma.de");
        dto.setDisplayName("Neu User");
        dto.setRole(AppUser.Role.VIEWER);
        dto.setInitialPassword("sicher123");

        when(userRepo.existsByEmail("neu@firma.de")).thenReturn(false);
        when(passwordEncoder.encode("sicher123")).thenReturn("$hash$");

        AppUser saved = AppUser.builder()
                .id(1L).email("neu@firma.de")
                .displayName("Neu User").role(AppUser.Role.VIEWER)
                .passwordHash("$hash$").build();
        when(userRepo.save(any())).thenReturn(saved);

        UserDTO result = userService.createUser(dto);
        assertThat(result.getEmail()).isEqualTo("neu@firma.de");
        verify(passwordEncoder).encode("sicher123");
    }

    @Test
    @DisplayName("createUser – Duplikat E-Mail")
    void createUser_duplicateEmail() {
        CreateUserDTO dto = new CreateUserDTO();
        dto.setEmail("exists@firma.de");
        when(userRepo.existsByEmail("exists@firma.de")).thenReturn(true);
        assertThrows(BusinessException.class, () -> userService.createUser(dto));
    }

    @Test
    @DisplayName("updateRole – letzten Admin schützen")
    void updateRole_protectLastAdmin() {
        AppUser admin = AppUser.builder().id(1L)
                .role(AppUser.Role.ADMIN).email("admin@firma.de").build();
        when(userRepo.findById(1L)).thenReturn(Optional.of(admin));
        when(userRepo.countByRole(AppUser.Role.ADMIN)).thenReturn(1L);

        assertThrows(BusinessException.class,
                () -> userService.updateRole(1L, AppUser.Role.VIEWER));
    }
}
```

### UserControllerIT.java (Integration)

```java
@SpringBootTest(webEnvironment = RANDOM_PORT)
@AutoConfigureMockMvc
@Testcontainers
class UserControllerIT {

    @Container
    static PostgreSQLContainer<?> postgres =
        new PostgreSQLContainer<>("postgres:16-alpine")
            .withDatabaseName("caems_test")
            .withUsername("test").withPassword("test");

    @DynamicPropertySource
    static void props(DynamicPropertyRegistry r) {
        r.add("spring.datasource.url",      postgres::getJdbcUrl);
        r.add("spring.datasource.username", postgres::getUsername);
        r.add("spring.datasource.password", postgres::getPassword);
    }

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper om;

    @Test
    @WithMockUser(roles = "ADMIN")
    void createUser_201() throws Exception {
        String body = """
            {
              "email": "new@firma.de",
              "displayName": "New User",
              "role": "VIEWER",
              "initialPassword": "sicher1234"
            }
            """;
        mockMvc.perform(post("/api/v1/admin/users")
                .contentType(APPLICATION_JSON).content(body))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.email").value("new@firma.de"))
            .andExpect(jsonPath("$.role").value("VIEWER"));
    }

    @Test
    @WithMockUser(roles = "HR")   // Kein Zugriff!
    void createUser_403_forNonAdmin() throws Exception {
        mockMvc.perform(post("/api/v1/admin/users")
                .contentType(APPLICATION_JSON)
                .content("{}"))
            .andExpect(status().isForbidden());
    }
}
```
